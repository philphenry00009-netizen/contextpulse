package dev.contextpulse.context_pulse

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.google.android.gms.location.ActivityRecognition
import com.google.android.gms.location.ActivityTransition
import com.google.android.gms.location.ActivityTransitionRequest
import com.google.android.gms.location.DetectedActivity

/**
 * Registers for Activity Recognition *transitions* (event-driven, no polling): Play Services
 * wakes our receiver only when the user starts/stops walking, driving, etc. This is the most
 * battery-friendly way to know the activity state. Requires ACTIVITY_RECOGNITION permission.
 */
object ActivityRegistrar {
    @SuppressLint("MissingPermission")
    fun register(ctx: Context, onDone: ((Boolean) -> Unit)? = null) {
        val types = listOf(
            DetectedActivity.STILL, DetectedActivity.WALKING, DetectedActivity.RUNNING,
            DetectedActivity.ON_BICYCLE, DetectedActivity.IN_VEHICLE,
        )
        val transitions = types.map {
            ActivityTransition.Builder()
                .setActivityType(it)
                .setActivityTransition(ActivityTransition.ACTIVITY_TRANSITION_ENTER)
                .build()
        }
        // Play Services adds extras to this intent, so the PendingIntent must be MUTABLE on Android 12+.
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        val pi = PendingIntent.getBroadcast(ctx, 0, Intent(ctx, ActivityTransitionReceiver::class.java), flags)
        try {
            ActivityRecognition.getClient(ctx)
                .requestActivityTransitionUpdates(ActivityTransitionRequest(transitions), pi)
                .addOnSuccessListener { onDone?.invoke(true) }
                .addOnFailureListener { onDone?.invoke(false) }
        } catch (e: SecurityException) {
            onDone?.invoke(false) // permission not granted yet
        }
    }

    fun typeName(t: Int) = when (t) {
        DetectedActivity.STILL -> "STILL"
        DetectedActivity.WALKING -> "WALKING"
        DetectedActivity.RUNNING -> "RUNNING"
        DetectedActivity.ON_BICYCLE -> "ON_BICYCLE"
        DetectedActivity.IN_VEHICLE -> "IN_VEHICLE"
        else -> "UNKNOWN"
    }
}
