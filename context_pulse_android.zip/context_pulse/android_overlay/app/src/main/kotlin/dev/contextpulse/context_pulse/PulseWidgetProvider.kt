package dev.contextpulse.context_pulse

import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.SharedPreferences
import android.view.View
import android.widget.RemoteViews
import es.antonborri.home_widget.HomeWidgetLaunchIntent
import es.antonborri.home_widget.HomeWidgetProvider

/** Home screen widget: context score + top 3 Pulse Cards, pushed from Dart after every tick. */
class PulseWidgetProvider : HomeWidgetProvider() {
    override fun onUpdate(
        context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray, widgetData: SharedPreferences,
    ) {
        val titles = intArrayOf(R.id.w_title_0, R.id.w_title_1, R.id.w_title_2)
        val bodies = intArrayOf(R.id.w_body_0, R.id.w_body_1, R.id.w_body_2)
        val rows = intArrayOf(R.id.w_row_0, R.id.w_row_1, R.id.w_row_2)
        val count = widgetData.getInt("w_count", 0)

        appWidgetIds.forEach { id ->
            val v = RemoteViews(context.packageName, R.layout.pulse_widget)
            v.setTextViewText(R.id.w_score, widgetData.getInt("w_score", 0).toString())
            v.setOnClickPendingIntent(R.id.w_root, HomeWidgetLaunchIntent.getActivity(context, MainActivity::class.java))
            for (i in 0..2) {
                val title = widgetData.getString("w_title_$i", "") ?: ""
                val show = i < count && title.isNotEmpty()
                v.setViewVisibility(rows[i], if (show) View.VISIBLE else View.GONE)
                if (show) {
                    v.setTextViewText(titles[i], title)
                    v.setTextViewText(bodies[i], widgetData.getString("w_body_$i", "") ?: "")
                }
            }
            v.setViewVisibility(R.id.w_empty, if (count == 0) View.VISIBLE else View.GONE)
            appWidgetManager.updateAppWidget(id, v)
        }
    }
}
