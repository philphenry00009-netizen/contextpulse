package dev.contextpulse.context_pulse

import android.content.Context

/**
 * Same file/prefix the Dart `shared_preferences` plugin uses, so Kotlin (tiles, receivers)
 * and Dart (UI + WorkManager isolates) can exchange small flags without a method channel.
 */
object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
    fun bool(c: Context, k: String, def: Boolean = false) = p(c).getBoolean("flutter.$k", def)
    fun putBool(c: Context, k: String, v: Boolean) = p(c).edit().putBoolean("flutter.$k", v).apply()
    fun putString(c: Context, k: String, v: String) = p(c).edit().putString("flutter.$k", v).apply()
    fun putLong(c: Context, k: String, v: Long) = p(c).edit().putLong("flutter.$k", v).apply()
}
