package dev.contextpulse.context_pulse

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.google.android.gms.location.ActivityTransitionResult

/** Receives transition events and stores the latest state for Dart to read on its next tick. */
class ActivityTransitionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            ActivityRegistrar.register(context) // registrations do not survive reboot
            return
        }
        if (!ActivityTransitionResult.hasResult(intent)) return
        val last = ActivityTransitionResult.extractResult(intent)?.transitionEvents?.lastOrNull() ?: return
        Prefs.putString(context, "cp_activity_type", ActivityRegistrar.typeName(last.activityType))
        Prefs.putLong(context, "cp_activity_ts", System.currentTimeMillis())
    }
}
