package dev.contextpulse.context_pulse

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Quick Settings tile: toggles the Focus profile (only high-priority cards). Pro feature. */
class FocusTileService : TileService() {
    override fun onStartListening() = refresh()

    override fun onClick() {
        if (!Prefs.bool(this, "cp_pro")) {
            TileLauncher.openApp(this, null) // not Pro: open the app (paywall lives there)
            return
        }
        Prefs.putBool(this, "cp_focus", !Prefs.bool(this, "cp_focus"))
        refresh()
    }

    private fun refresh() {
        val t = qsTile ?: return
        val pro = Prefs.bool(this, "cp_pro")
        t.state = if (pro && Prefs.bool(this, "cp_focus")) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = if (pro) "Focus" else "Focus (Pro)"
        t.updateTile()
    }
}
