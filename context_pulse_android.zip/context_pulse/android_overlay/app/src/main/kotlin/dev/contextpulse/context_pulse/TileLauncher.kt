package dev.contextpulse.context_pulse

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.TileService

object TileLauncher {
    @Suppress("DEPRECATION")
    fun openApp(svc: TileService, action: String?) {
        val i = svc.packageManager.getLaunchIntentForPackage(svc.packageName) ?: return
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (action != null) i.putExtra("cp_action", action)
        if (Build.VERSION.SDK_INT >= 34) {
            val pi = PendingIntent.getActivity(svc, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            svc.startActivityAndCollapse(pi)
        } else {
            svc.startActivityAndCollapse(i)
        }
    }
}
