package dev.contextpulse.context_pulse

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.util.Base64
import com.google.android.play.core.integrity.IntegrityManagerFactory
import com.google.android.play.core.integrity.IntegrityTokenRequest
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.Signature
import java.security.spec.X509EncodedKeySpec

class MainActivity : FlutterActivity() {
    private val channel = "dev.contextpulse/native"

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        handleLaunchIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleLaunchIntent(intent)
    }

    /** "Scan now" tile / notification taps pass cp_action=scan; Dart consumes it from SharedFlags. */
    private fun handleLaunchIntent(i: Intent?) {
        i?.getStringExtra("cp_action")?.let { Prefs.putString(this, "cp_launch_action", it) }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channel).setMethodCallHandler { call, result ->
            when (call.method) {
                "packageName" -> result.success(packageName)
                "startActivityUpdates" -> ActivityRegistrar.register(applicationContext) { result.success(it) }
                "signingCertSha256" -> result.success(signingCertSha256())
                "installerPackage" -> result.success(installer())
                "isRooted" -> result.success(isRooted())
                "verifyPlaySignature" -> result.success(
                    verifyPlaySignature(call.argument("key")!!, call.argument("json")!!, call.argument("sig")!!)
                )
                "integrityToken" -> requestIntegrityToken(
                    call.argument("nonce")!!, (call.argument<Number>("project") ?: 0).toLong(), result
                )
                "isIgnoringBatteryOptimizations" -> result.success(
                    (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
                )
                // Opens the system list (no REQUEST_IGNORE_BATTERY_OPTIMIZATIONS permission needed,
                // which Google Play restricts to apps whose core function requires it).
                "requestIgnoreBatteryOptimizations" -> {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        }
    }

    // ------------------------------------------------------------------ security
    @Suppress("DEPRECATION")
    private fun signingCertSha256(): String? = try {
        val sig = if (Build.VERSION.SDK_INT >= 28) {
            val info = packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNING_CERTIFICATES)
            info.signingInfo?.apkContentsSigners?.firstOrNull()
        } else {
            packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNATURES).signatures?.firstOrNull()
        }
        sig?.let { MessageDigest.getInstance("SHA-256").digest(it.toByteArray()).joinToString("") { b -> "%02x".format(b) } }
    } catch (e: Exception) { null }

    @Suppress("DEPRECATION")
    private fun installer(): String? = try {
        if (Build.VERSION.SDK_INT >= 30) packageManager.getInstallSourceInfo(packageName).installingPackageName
        else packageManager.getInstallerPackageName(packageName)
    } catch (e: Exception) { null }

    /** Basic heuristics only: files that commonly exist on rooted devices + test-keys build. */
    private fun isRooted(): Boolean {
        if (Build.TAGS?.contains("test-keys") == true) return true
        val paths = listOf(
            "/system/bin/su", "/system/xbin/su", "/sbin/su", "/system/su", "/su/bin/su",
            "/system/app/Superuser.apk", "/data/local/xbin/su", "/data/local/bin/su",
        )
        return paths.any { File(it).exists() }
    }

    /** Google Play signs purchase JSON with SHA1withRSA using your app's licensing key. */
    private fun verifyPlaySignature(keyB64: String, json: String, sigB64: String): Boolean = try {
        val pub = KeyFactory.getInstance("RSA").generatePublic(X509EncodedKeySpec(Base64.decode(keyB64, Base64.DEFAULT)))
        val s = Signature.getInstance("SHA1withRSA")
        s.initVerify(pub)
        s.update(json.toByteArray(Charsets.UTF_8))
        s.verify(Base64.decode(sigB64, Base64.DEFAULT))
    } catch (e: Exception) { false }

    /** The token is opaque here; only your server can decrypt it via Google's API. */
    private fun requestIntegrityToken(nonce: String, project: Long, result: MethodChannel.Result) {
        try {
            IntegrityManagerFactory.create(applicationContext)
                .requestIntegrityToken(
                    IntegrityTokenRequest.builder().setNonce(nonce).setCloudProjectNumber(project).build()
                )
                .addOnSuccessListener { result.success(it.token()) }
                .addOnFailureListener { result.success(null) }
        } catch (e: Exception) { result.success(null) }
    }
}
