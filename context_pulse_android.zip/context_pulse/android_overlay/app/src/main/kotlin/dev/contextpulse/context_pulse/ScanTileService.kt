package dev.contextpulse.context_pulse

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Quick Settings tile: opens the app and triggers an immediate context scan. Pro feature. */
class ScanTileService : TileService() {
    override fun onStartListening() {
        val t = qsTile ?: return
        t.state = Tile.STATE_INACTIVE
        t.label = if (Prefs.bool(this, "cp_pro")) "Scan now" else "Scan (Pro)"
        t.updateTile()
    }

    override fun onClick() {
        TileLauncher.openApp(this, if (Prefs.bool(this, "cp_pro")) "scan" else null)
    }
}
