# android/app/build.gradle.kts (Flutter 3.27+ template)

```kotlin
android {
    compileOptions {
        isCoreLibraryDesugaringEnabled = true      // required by flutter_local_notifications
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    defaultConfig {
        minSdk = 24
    }
    buildTypes {
        release {
            isMinifyEnabled = true        // R8 shrinks/obfuscates the Kotlin/Java side
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("release") // your upload key
        }
    }
}

dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")
    implementation("com.google.android.gms:play-services-location:21.3.0")  // Activity Transition API
    implementation("com.google.android.play:integrity:1.4.0")               // Play Integrity API
}
```

Create `android/app/proguard-rules.pro` (can be empty; Flutter ships its own keep rules).

Release build (Dart AOT + symbol obfuscation; AAB is what Play requires):

```bash
flutter build appbundle --release --obfuscate --split-debug-info=build/symbols
```
Keep `build/symbols` private; it is needed to de-obfuscate crash stack traces.
