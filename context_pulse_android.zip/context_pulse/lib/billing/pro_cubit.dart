import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'billing_service.dart';
import 'license_validator.dart';

class ProState {
  const ProState({this.isPro = false, this.products = const [], this.loading = true});
  final bool isPro;
  final List<ProductDetails> products;
  final bool loading;
  ProState copyWith({bool? isPro, List<ProductDetails>? products, bool? loading}) => ProState(
      isPro: isPro ?? this.isPro, products: products ?? this.products, loading: loading ?? this.loading);
}

/// Source of truth for "is this user Pro right now?" in the UI.
class ProCubit extends Cubit<ProState> {
  ProCubit(this._validator, this._billing) : super(const ProState());
  final LicenseValidator _validator;
  final BillingService _billing;
  StreamSubscription<Entitlement?>? _sub;

  Future<void> start() async {
    // 1) Instant, offline: verify cached receipt.
    final e = await _validator.revalidate();
    emit(state.copyWith(isPro: e != null, loading: false));
    // 2) Online: talk to Play, update when receipts arrive.
    _sub = _billing.proChanged.stream.listen((e) => emit(state.copyWith(isPro: e != null)));
    _billing.products.addListener(() => emit(state.copyWith(products: _billing.products.value)));
    await _billing.init();
    emit(state.copyWith(products: _billing.products.value));
  }

  Future<void> buy(ProductDetails p) => _billing.buy(p);

  @override
  Future<void> close() {
    _sub?.cancel();
    _billing.dispose();
    return super.close();
  }
}
