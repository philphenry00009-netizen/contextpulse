import 'dart:convert';
import 'package:flutter/foundation.dart';
import '../core/app_config.dart';
import '../core/native_bridge.dart';
import '../core/secure_store.dart';
import '../core/shared_flags.dart';

/// Cached, locally verified Pro entitlement.
class Entitlement {
  const Entitlement({required this.productId, required this.verifiedAt});
  final String productId;
  final DateTime verifiedAt;
  static const none = null;
}

/// Verifies Google Play purchase receipts OFFLINE and caches them in the Keystore-backed store.
///
/// How trust works:
///  * Play signs every purchase's JSON with the app's Play licensing RSA key.
///  * We verify that signature natively (java.security.Signature, SHA1withRSA, which is what
///    Play uses), plus package name, product id and purchase state.
///  * The verified receipt is stored encrypted (Keystore master key). The UI isolate re-verifies it
///    on every launch; the WorkManager isolate (no native channel) trusts the cached record.
///  * Pro stays valid for [AppConfig.proGrace] after the last time Play re-confirmed the purchase.
///
/// Limits (be aware): purely client-side checks can be patched by a determined attacker on a
/// rooted/modified device. Play Integrity (see integrity_guard.dart) and, ideally, server-side
/// purchase verification are the real defences.
class LicenseValidator {
  LicenseValidator([SecureStore? store]) : _store = store ?? SecureStore();
  final SecureStore _store;

  static const _kReceipt = 'pro_receipt_json';
  static const _kSignature = 'pro_receipt_sig';
  static const _kVerifiedAt = 'pro_verified_at';
  static const _kProduct = 'pro_product';

  /// Verify a fresh purchase/restore from Play; on success persist and return true.
  Future<bool> verifyAndStore({
    required String receiptJson,
    required String signature,
  }) async {
    if (AppConfig.playLicenseKeyBase64.startsWith('REPLACE')) {
      debugPrint('LicenseValidator: playLicenseKeyBase64 not configured.');
      return false;
    }
    final sigOk = await NativeBridge.verifyPlaySignature(
        AppConfig.playLicenseKeyBase64, receiptJson, signature);
    if (!sigOk) return false;

    final Map<String, dynamic> j;
    try {
      j = jsonDecode(receiptJson) as Map<String, dynamic>;
    } catch (_) {
      return false;
    }
    final productId = j['productId'] as String?;
    final purchased = (j['purchaseState'] ?? 0) == 0; // 0 = PURCHASED, 1 = CANCELED, 2 = PENDING
    final pkgOk = j['packageName'] == await NativeBridge.packageName();
    if (productId == null || !AppConfig.proIds.contains(productId) || !purchased || !pkgOk) {
      return false;
    }
    await _store.write(_kReceipt, receiptJson);
    await _store.write(_kSignature, signature);
    await _store.write(_kProduct, productId);
    await _store.write(_kVerifiedAt, DateTime.now().millisecondsSinceEpoch.toString());
    await SharedFlags.setPro(true);
    return true;
  }

  /// UI isolate: re-verify the stored receipt's signature (detects tampered storage).
  /// Returns the entitlement or null; clears the cache if the signature no longer verifies.
  Future<Entitlement?> revalidate() async {
    final json = await _store.read(_kReceipt);
    final sig = await _store.read(_kSignature);
    if (json == null || sig == null) return _publish(null);
    final ok = await NativeBridge.verifyPlaySignature(AppConfig.playLicenseKeyBase64, json, sig);
    if (!ok) {
      await clear();
      return null;
    }
    return _publish(await cached());
  }

  /// Pure-Dart read of the cached record (safe in the background isolate).
  Future<Entitlement?> cached() async {
    final at = int.tryParse(await _store.read(_kVerifiedAt) ?? '');
    final product = await _store.read(_kProduct);
    if (at == null || product == null) return null;
    final verifiedAt = DateTime.fromMillisecondsSinceEpoch(at);
    if (DateTime.now().difference(verifiedAt) > AppConfig.proGrace) return null; // grace expired
    if (verifiedAt.isAfter(DateTime.now().add(const Duration(days: 1)))) return null; // clock rollback
    return Entitlement(productId: product, verifiedAt: verifiedAt);
  }

  Future<bool> isPro() async => (await cached()) != null;

  Future<void> clear() async {
    for (final k in [_kReceipt, _kSignature, _kVerifiedAt, _kProduct]) {
      await _store.delete(k);
    }
    await SharedFlags.setPro(false);
  }

  Future<Entitlement?> _publish(Entitlement? e) async {
    await SharedFlags.setPro(e != null);
    return e;
  }
}
