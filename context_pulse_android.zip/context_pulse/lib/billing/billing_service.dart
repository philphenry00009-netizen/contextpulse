import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:in_app_purchase_android/in_app_purchase_android.dart';
import '../core/app_config.dart';
import 'license_validator.dart';

/// Wraps Google Play Billing (via in_app_purchase). Every purchase/restore event goes through
/// [LicenseValidator]; nothing unlocks Pro without a signature-valid receipt.
class BillingService {
  BillingService(this._validator);
  final LicenseValidator _validator;
  final _iap = InAppPurchase.instance;
  StreamSubscription<List<PurchaseDetails>>? _sub;

  final products = ValueNotifier<List<ProductDetails>>([]);
  final proChanged = StreamController<Entitlement?>.broadcast();

  Future<void> init() async {
    if (!await _iap.isAvailable()) return;
    _sub = _iap.purchaseStream.listen(_onPurchases, onError: (e) => debugPrint('billing: $e'));
    final res = await _iap.queryProductDetails(AppConfig.proIds);
    products.value = res.productDetails;
    // Re-confirm ownership with Play whenever we are online; refreshes the offline grace window.
    await _iap.restorePurchases();
  }

  Future<void> buy(ProductDetails p) async {
    final param = PurchaseParam(productDetails: p);
    await _iap.buyNonConsumable(purchaseParam: param); // subscriptions use this call
  }

  Future<void> _onPurchases(List<PurchaseDetails> list) async {
    for (final p in list) {
      if (!AppConfig.proIds.contains(p.productID)) continue;
      if (p.status == PurchaseStatus.purchased || p.status == PurchaseStatus.restored) {
        if (p is GooglePlayPurchaseDetails) {
          final bp = p.billingClientPurchase;
          final ok = await _validator.verifyAndStore(
              receiptJson: bp.originalJson, signature: bp.signature);
          proChanged.add(ok ? await _validator.cached() : null);
        }
      }
      if (p.pendingCompletePurchase) await _iap.completePurchase(p); // acknowledge
    }
  }

  void dispose() {
    _sub?.cancel();
    proChanged.close();
  }
}
