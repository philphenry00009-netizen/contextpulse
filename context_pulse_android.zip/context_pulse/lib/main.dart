import 'package:flutter/material.dart';
import 'app.dart';
import 'application/background_service.dart';
import 'application/context_engine.dart';
import 'application/notification_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final engine = await ContextEngine.create(); // opens the SQLCipher DB
  engine.habits.seedIfEmpty();
  await NotificationService.init();
  await BackgroundService.register();
  runApp(ContextPulseApp(engine: engine));
}
