import 'package:dynamic_color/dynamic_color.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'application/context_engine.dart';
import 'billing/billing_service.dart';
import 'billing/license_validator.dart';
import 'billing/pro_cubit.dart';
import 'core/theme.dart';
import 'presentation/bloc/pulse_bloc.dart';
import 'presentation/bloc/theme_cubit.dart';
import 'presentation/pages/home_shell.dart';
import 'presentation/pages/security_gate.dart';

class ContextPulseApp extends StatelessWidget {
  const ContextPulseApp({super.key, required this.engine});
  final ContextEngine engine;

  @override
  Widget build(BuildContext context) {
    final validator = LicenseValidator();
    return MultiBlocProvider(
      providers: [
        BlocProvider(create: (_) => ProCubit(validator, BillingService(validator))..start()),
        BlocProvider(create: (_) => ThemeCubit()..load()),
        BlocProvider(create: (_) => PulseBloc(engine)..add(const PulseStarted())),
      ],
      child: DynamicColorBuilder(
        builder: (lightDyn, darkDyn) => BlocBuilder<ThemeCubit, int>(
          builder: (context, seed) {
            final isPro = context.select((ProCubit c) => c.state.isPro);
            // Pro + chosen seed -> custom scheme. Otherwise Monet dynamic colour, or a seed fallback.
            ColorScheme scheme(Brightness b) {
              if (isPro && seed != -1) return ColorScheme.fromSeed(seedColor: Color(seed), brightness: b);
              final dyn = b == Brightness.light ? lightDyn : darkDyn;
              return dyn?.harmonized() ?? ColorScheme.fromSeed(seedColor: AppTheme.fallbackSeed, brightness: b);
            }

            return MaterialApp(
              title: 'ContextPulse',
              debugShowCheckedModeBanner: false,
              theme: AppTheme.build(scheme(Brightness.light)),
              darkTheme: AppTheme.build(scheme(Brightness.dark)),
              themeMode: ThemeMode.system, // adaptive light/dark
              home: const SecurityGate(child: HomeShell()),
            );
          },
        ),
      ),
    );
  }
}
