import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../billing/pro_cubit.dart';
import '../../core/app_config.dart';

/// Shows the Pro upsell. Prices come from Play (localised); fallbacks shown until loaded.
Future<void> showPaywall(BuildContext context, {String? reason}) {
  final cubit = context.read<ProCubit>();
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (_) => BlocProvider.value(value: cubit, child: _Paywall(reason: reason)),
  );
}

class _Paywall extends StatelessWidget {
  const _Paywall({this.reason});
  final String? reason;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return BlocBuilder<ProCubit, ProState>(builder: (context, st) {
      if (st.isPro) {
        return const Padding(padding: EdgeInsets.all(32), child: Text('You are Pro. Thank you!'));
      }
      final cubit = context.read<ProCubit>();
      Widget tile(String id, String fallback, String label) {
        final p = st.products.where((e) => e.id == id).toList();
        return Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: FilledButton.tonal(
            onPressed: p.isEmpty ? null : () => cubit.buy(p.first),
            child: Text('$label  -  ${p.isEmpty ? fallback : p.first.price}'),
          ),
        );
      }

      return Padding(
        padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('ContextPulse Pro', style: Theme.of(context).textTheme.headlineSmall),
          if (reason != null) Padding(padding: const EdgeInsets.only(top: 4), child: Text(reason!, style: TextStyle(color: cs.onSurfaceVariant))),
          const SizedBox(height: 12),
          for (final f in const [
            'Unlimited custom trigger rules (location + battery + time)',
            'Unlimited daily cards',
            'Quick Settings tiles (Focus, Scan now)',
            'Custom Material themes',
            'JSON / CSV data export',
          ])
            Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: Row(children: [
              Icon(Icons.check_circle_rounded, size: 18, color: cs.primary), const SizedBox(width: 8), Expanded(child: Text(f)),
            ])),
          const SizedBox(height: 16),
          tile(AppConfig.proYearlyId, '\$14.99 / year', 'Yearly'),
          tile(AppConfig.proMonthlyId, '\$1.99 / month', 'Monthly'),
          if (st.products.isEmpty)
            Text('Prices load from Google Play (needs a Play-installed build).', style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
        ]),
      );
    });
  }
}
