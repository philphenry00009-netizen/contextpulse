import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../domain/entities.dart';

IconData iconForType(CardType t) => switch (t) {
      CardType.calendar => Icons.event_rounded,
      CardType.habit => Icons.bolt_rounded,
      CardType.battery => Icons.battery_alert_rounded,
      CardType.offline => Icons.cloud_off_rounded,
      CardType.planning => Icons.wb_twilight_rounded,
      CardType.wrapUp => Icons.nights_stay_rounded,
      CardType.custom => Icons.auto_fix_high_rounded,
    };

/// M3 card. Swipe right = complete, left = snooze, tap = details. Entrance is a
/// staggered fade + rise; removal uses Dismissible's collapse animation.
class PulseCardWidget extends StatelessWidget {
  const PulseCardWidget({
    super.key,
    required this.card,
    required this.index,
    required this.onComplete,
    required this.onSnooze,
    required this.onTap,
  });

  final PulseCard card;
  final int index;
  final VoidCallback onComplete, onSnooze, onTap;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final accent = AppTheme.scoreColor(cs, card.score);
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 320 + index * 90),
      curve: Curves.easeOutCubic,
      builder: (_, t, child) => Opacity(
          opacity: t, child: Transform.translate(offset: Offset(0, 28 * (1 - t)), child: child)),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 6, 16, 6),
        child: Dismissible(
          key: ValueKey('d-${card.id}'),
          background: _bg(cs.primaryContainer, cs.onPrimaryContainer, Icons.check_rounded, 'Done', Alignment.centerLeft),
          secondaryBackground: _bg(cs.secondaryContainer, cs.onSecondaryContainer, Icons.snooze_rounded, 'Snooze', Alignment.centerRight),
          onDismissed: (d) => d == DismissDirection.startToEnd ? onComplete() : onSnooze(),
          child: Card.filled(
            margin: EdgeInsets.zero,
            color: cs.surfaceContainerHigh,
            clipBehavior: Clip.antiAlias,
            child: InkWell( // M3 ink ripple
              onTap: onTap,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  CircleAvatar(
                    backgroundColor: accent.withValues(alpha: 0.18),
                    child: Icon(iconForType(card.type), color: accent),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(card.title,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.titleMedium),
                      const SizedBox(height: 4),
                      Text(card.body,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context)
                              .textTheme
                              .bodyMedium
                              ?.copyWith(color: cs.onSurfaceVariant)),
                      const SizedBox(height: 10),
                      LinearProgressIndicator(
                          value: card.score / 100, minHeight: 4, color: accent,
                          backgroundColor: cs.surfaceContainerHighest,
                          borderRadius: BorderRadius.circular(4)),
                    ]),
                  ),
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _bg(Color bg, Color fg, IconData i, String label, Alignment a) => Container(
        alignment: a,
        padding: const EdgeInsets.symmetric(horizontal: 24),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(24)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(i, color: fg),
          const SizedBox(width: 8),
          Text(label, style: TextStyle(color: fg, fontWeight: FontWeight.w600)),
        ]),
      );
}
