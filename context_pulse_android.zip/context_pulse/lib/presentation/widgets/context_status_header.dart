import 'package:flutter/material.dart';
import '../../domain/entities.dart';
import '../bloc/pulse_bloc.dart';

class ContextStatusHeader extends StatelessWidget {
  const ContextStatusHeader({super.key, required this.state, required this.isPro});
  final PulseState state;
  final bool isPro;

  String get _greeting {
    final h = DateTime.now().hour;
    return h < 5 ? 'Late night' : h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;
    final s = state.signal;
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          SizedBox(
            width: 68,
            height: 68,
            child: Stack(alignment: Alignment.center, children: [
              TweenAnimationBuilder<double>(
                tween: Tween(begin: 0, end: state.contextScore / 100),
                duration: const Duration(milliseconds: 700),
                curve: Curves.easeOutCubic,
                builder: (_, v, __) => SizedBox.expand(
                    child: CircularProgressIndicator(
                        value: v, strokeWidth: 6, strokeCap: StrokeCap.round,
                        backgroundColor: cs.surfaceContainerHighest)),
              ),
              Text(state.contextScore.round().toString(), style: tt.titleLarge),
            ]),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(_greeting, style: tt.headlineSmall),
              Text('Context score', style: tt.bodyMedium?.copyWith(color: cs.onSurfaceVariant)),
            ]),
          ),
          if (isPro) Chip(label: const Text('PRO'), visualDensity: VisualDensity.compact, backgroundColor: cs.tertiaryContainer),
          if (state.loading)
            const Padding(
                padding: EdgeInsets.only(left: 8),
                child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))),
        ]),
        const SizedBox(height: 14),
        if (s != null)
          Wrap(spacing: 8, runSpacing: 4, children: [
            _chip(Icon(_activityIcon(s.activity), size: 18), s.activity.name),
            _chip(Icon(_netIcon(s.network), size: 18), s.network.name),
            _chip(Icon(s.isCharging ? Icons.battery_charging_full_rounded : Icons.battery_std_rounded, size: 18),
                '${s.batteryLevel}%'),
            if (s.focusMode) _chip(const Icon(Icons.do_not_disturb_on_rounded, size: 18), 'focus'),
            if (s.nextEvent != null) _chip(const Icon(Icons.event_rounded, size: 18), _nextLabel(s)),
          ]),
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 250),
          child: state.offline
              ? Card.filled(
                  key: const ValueKey('offline'),
                  color: cs.errorContainer,
                  margin: const EdgeInsets.only(top: 12),
                  child: ListTile(
                    dense: true,
                    leading: Icon(Icons.cloud_off_rounded, color: cs.onErrorContainer),
                    title: Text(
                      state.pendingQueue > 0
                          ? 'Offline - ${state.pendingQueue} queued, will sync automatically'
                          : 'Offline - everything still works locally',
                      style: TextStyle(color: cs.onErrorContainer),
                    ),
                  ),
                )
              : const SizedBox.shrink(key: ValueKey('online')),
        ),
      ]),
    );
  }

  String _nextLabel(ContextSignal s) {
    final m = s.minutesToNextEvent ?? 0;
    return m <= 0 ? 'now: ${s.nextEvent!.title}' : 'in ${m}m: ${s.nextEvent!.title}';
  }

  IconData _activityIcon(ActivityState a) => switch (a) {
        ActivityState.stationary => Icons.chair_alt_rounded,
        ActivityState.walking => Icons.directions_walk_rounded,
        ActivityState.driving => Icons.directions_car_rounded,
        ActivityState.unknown => Icons.help_outline_rounded,
      };

  IconData _netIcon(NetworkState n) => switch (n) {
        NetworkState.wifi => Icons.wifi_rounded,
        NetworkState.cellular => Icons.signal_cellular_alt_rounded,
        NetworkState.offline => Icons.wifi_off_rounded,
      };

  Widget _chip(Icon i, String t) => Chip(
        avatar: i,
        label: Text(t, overflow: TextOverflow.ellipsis),
        visualDensity: VisualDensity.compact,
      );
}
