import 'package:flutter/material.dart';
import 'dashboard_page.dart';
import 'rules_page.dart';
import 'settings_page.dart';

/// M3 NavigationBar shell. Predictive back is handled by the theme's page transitions.
class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _i = 0;
  static const _pages = [DashboardPage(), RulesPage(), SettingsPage()];

  @override
  Widget build(BuildContext context) => PopScope(
        canPop: _i == 0, // back from Rules/Settings returns to Pulse first
        onPopInvokedWithResult: (didPop, _) {
          if (!didPop) setState(() => _i = 0);
        },
        child: Scaffold(
          body: IndexedStack(index: _i, children: _pages),
          bottomNavigationBar: NavigationBar(
            selectedIndex: _i,
            onDestinationSelected: (v) => setState(() => _i = v),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.bolt_outlined), selectedIcon: Icon(Icons.bolt_rounded), label: 'Pulse'),
              NavigationDestination(icon: Icon(Icons.rule_outlined), selectedIcon: Icon(Icons.rule_rounded), label: 'Rules'),
              NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings_rounded), label: 'Settings'),
            ],
          ),
        ),
      );
}
