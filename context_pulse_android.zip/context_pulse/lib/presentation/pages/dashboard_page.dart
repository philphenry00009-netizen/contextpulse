import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../billing/pro_cubit.dart';
import '../bloc/pulse_bloc.dart';
import '../widgets/context_status_header.dart';
import '../widgets/pulse_card_widget.dart';
import '../widgets/pulse_detail_sheet.dart';
import '../widgets/quick_action_button.dart';
import '../widgets/quick_log_sheet.dart';

/// The Pulse Stream: max 5 cards, swipe right to complete, left to snooze.
class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) context.read<PulseBloc>().add(const PulseRefreshed());
  }

  void _toast(String m) => ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(m)));

  Future<void> _refresh() async {
    final bloc = context.read<PulseBloc>();
    final done = bloc.stream.firstWhere((s) => !s.loading).timeout(const Duration(seconds: 10), onTimeout: () => bloc.state);
    bloc.add(const PulseRefreshed());
    await done;
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final isPro = context.select((ProCubit c) => c.state.isPro);
    return BlocBuilder<PulseBloc, PulseState>(builder: (context, state) {
      final bloc = context.read<PulseBloc>();
      return Column(children: [
        Expanded(
          child: SafeArea(
            bottom: false,
            child: RefreshIndicator(
              onRefresh: _refresh,
              child: CustomScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                slivers: [
                  SliverToBoxAdapter(child: ContextStatusHeader(state: state, isPro: isPro)),
                  if (state.cards.isEmpty)
                    SliverFillRemaining(
                      hasScrollBody: false,
                      child: Center(
                        child: Column(mainAxisSize: MainAxisSize.min, children: [
                          Icon(Icons.auto_awesome_rounded, size: 44, color: cs.outline),
                          const SizedBox(height: 12),
                          Text('All clear', style: Theme.of(context).textTheme.titleMedium),
                          Text('Nothing needs you right now.', style: TextStyle(color: cs.onSurfaceVariant)),
                        ]),
                      ),
                    )
                  else
                    SliverList(
                      delegate: SliverChildBuilderDelegate(
                        childCount: state.cards.length,
                        (context, i) {
                          final card = state.cards[i];
                          return PulseCardWidget(
                            key: ValueKey(card.id),
                            card: card,
                            index: i,
                            onComplete: () {
                              bloc.add(PulseCardCompleted(card));
                              _toast('Done: ${card.title}');
                            },
                            onSnooze: () {
                              bloc.add(PulseCardSnoozed(card));
                              _toast('Snoozed 30 min');
                            },
                            onTap: () => showPulseDetailSheet(context, card),
                          );
                        },
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
          child: Row(children: [
            QuickActionButton(icon: Icons.payments_rounded, label: 'Expense', onTap: () => showQuickLogSheet(context, QuickKind.expense)),
            QuickActionButton(icon: Icons.edit_note_rounded, label: 'Note', onTap: () => showQuickLogSheet(context, QuickKind.note)),
            QuickActionButton(icon: Icons.reply_rounded, label: 'Reply', onTap: () => showQuickLogSheet(context, QuickKind.reply)),
            QuickActionButton(icon: Icons.check_circle_outline_rounded, label: 'Habit', onTap: () => showQuickLogSheet(context, QuickKind.habit)),
          ]),
        ),
      ]);
    });
  }
}
