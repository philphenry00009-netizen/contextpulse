import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../application/export_service.dart';
import '../../billing/pro_cubit.dart';
import '../../core/native_bridge.dart';
import '../../core/secure_store.dart';
import '../../core/shared_flags.dart';
import '../../core/theme.dart';
import '../bloc/pulse_bloc.dart';
import '../bloc/theme_cubit.dart';
import '../widgets/paywall_sheet.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final _store = SecureStore();
  final _key = TextEditingController();
  final _habit = TextEditingController();
  bool _ai = false, _focus = false, _ignoringBattery = false;
  int _hour = 9;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final on = await _store.aiOptIn();
    final k = await _store.aiKey();
    final f = await SharedFlags.focusOn();
    final b = await NativeBridge.isIgnoringBatteryOptimizations();
    if (!mounted) return;
    setState(() {
      _ai = on;
      _key.text = k ?? '';
      _focus = f;
      _ignoringBattery = b;
    });
  }

  @override
  void dispose() {
    _key.dispose();
    _habit.dispose();
    super.dispose();
  }

  Future<void> _export(bool json) async {
    final svc = ExportService(context.read<PulseBloc>().engine);
    final f = json ? await svc.exportJson() : await svc.exportCsv();
    await svc.shareFile(f);
  }

  @override
  Widget build(BuildContext context) {
    final bloc = context.read<PulseBloc>();
    final pro = context.watch<ProCubit>().state.isPro;
    final seed = context.watch<ThemeCubit>().state;
    final cs = Theme.of(context).colorScheme;
    final habits = bloc.engine.habits.all();

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(padding: const EdgeInsets.only(bottom: 32), children: [
        Card.filled(
          color: pro ? cs.tertiaryContainer : cs.primaryContainer,
          margin: const EdgeInsets.all(16),
          child: ListTile(
            leading: Icon(pro ? Icons.workspace_premium_rounded : Icons.auto_awesome_rounded),
            title: Text(pro ? 'ContextPulse Pro' : 'Upgrade to Pro'),
            subtitle: Text(pro ? 'All features unlocked' : 'Rules, tiles, themes, export, unlimited cards'),
            onTap: pro ? null : () => showPaywall(context),
          ),
        ),
        _header('Focus profile'),
        SwitchListTile(
          title: const Text('Focus mode'),
          subtitle: const Text('Only high-priority cards (also togglable from the Quick Settings tile)'),
          value: _focus,
          onChanged: (v) {
            setState(() => _focus = v);
            bloc.add(PulseFocusSet(v));
          },
        ),
        _header('Appearance'),
        ListTile(
          title: Text(pro ? 'Theme colour' : 'Theme colour (Pro)'),
          subtitle: Text(seed == -1 || !pro ? 'Material You (wallpaper colours)' : 'Custom'),
          trailing: pro ? null : const Icon(Icons.lock_rounded),
          onTap: pro ? null : () => showPaywall(context, reason: 'Custom Material themes are a Pro feature.'),
        ),
        if (pro)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Wrap(spacing: 8, runSpacing: 8, children: [
              ChoiceChip(
                label: const Text('Material You'),
                selected: seed == -1,
                onSelected: (_) => context.read<ThemeCubit>().setSeed(-1),
              ),
              for (final e in AppTheme.proSeeds.entries)
                ChoiceChip(
                  avatar: CircleAvatar(backgroundColor: e.value, radius: 8),
                  label: Text(e.key),
                  selected: seed == e.value.toARGB32(),
                  onSelected: (_) => context.read<ThemeCubit>().setSeed(e.value.toARGB32()),
                ),
            ]),
          ),
        _header('Habits'),
        for (final h in habits)
          ListTile(
            title: Text(h.title),
            subtitle: Text('around ${h.hour.toString().padLeft(2, '0')}:00'),
            trailing: IconButton(
              icon: const Icon(Icons.delete_outline_rounded),
              onPressed: () {
                bloc.engine.habits.remove(h.id!);
                setState(() {});
              },
            ),
          ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(children: [
            Expanded(child: TextField(controller: _habit, decoration: const InputDecoration(labelText: 'New habit'))),
            const SizedBox(width: 8),
            DropdownButton<int>(
              value: _hour,
              items: [for (var i = 0; i < 24; i++) DropdownMenuItem(value: i, child: Text('${i.toString().padLeft(2, '0')}:00'))],
              onChanged: (v) => setState(() => _hour = v ?? _hour),
            ),
            IconButton.filledTonal(
              icon: const Icon(Icons.add_rounded),
              onPressed: () {
                if (_habit.text.trim().isEmpty) return;
                bloc.engine.habits.add(_habit.text.trim(), _hour);
                _habit.clear();
                bloc.add(const PulseRefreshed());
                setState(() {});
              },
            ),
          ]),
        ),
        _header('Battery & background'),
        ListTile(
          title: const Text('Battery optimisation whitelist'),
          subtitle: Text(_ignoringBattery
              ? 'Exempt: background checks run on schedule'
              : 'Optional. Lets Android run the 15-minute check on time. Costs little battery.'),
          trailing: _ignoringBattery ? const Icon(Icons.check_circle_rounded) : null,
          onTap: _ignoringBattery
              ? null
              : () async {
                  await NativeBridge.requestIgnoreBatteryOptimizations();
                  await Future<void>.delayed(const Duration(seconds: 1));
                  _load();
                },
        ),
        _header('Data export'),
        ListTile(
          leading: Icon(pro ? Icons.data_object_rounded : Icons.lock_rounded),
          title: const Text('Export JSON'),
          onTap: pro ? () => _export(true) : () => showPaywall(context, reason: 'Data export is a Pro feature.'),
        ),
        ListTile(
          leading: Icon(pro ? Icons.table_chart_rounded : Icons.lock_rounded),
          title: const Text('Export CSV (actions)'),
          onTap: pro ? () => _export(false) : () => showPaywall(context, reason: 'Data export is a Pro feature.'),
        ),
        _header('Privacy'),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Text('All context data stays in an AES-256 encrypted database on this device. No analytics are sent anywhere.'),
        ),
        SwitchListTile(
          title: const Text('AI wording (optional)'),
          subtitle: const Text('Sends only generic card text (never calendar events) to Gemini with your own API key.'),
          value: _ai,
          onChanged: (v) async {
            await _store.setAiOptIn(v);
            setState(() => _ai = v);
          },
        ),
        if (_ai)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TextField(controller: _key, obscureText: true, decoration: const InputDecoration(labelText: 'Gemini API key'), onChanged: _store.setAiKey),
          ),
      ]),
    );
  }

  Widget _header(String t) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 4),
        child: Text(t, style: Theme.of(context).textTheme.titleSmall?.copyWith(color: Theme.of(context).colorScheme.primary)),
      );
}
