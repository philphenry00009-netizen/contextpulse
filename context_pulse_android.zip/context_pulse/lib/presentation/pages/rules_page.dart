import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../billing/pro_cubit.dart';
import '../../domain/rules.dart';
import '../bloc/pulse_bloc.dart';
import '../bloc/rule_builder_cubit.dart';
import '../widgets/paywall_sheet.dart';
import 'rule_builder_page.dart';

/// Pro: list / enable / edit / delete custom trigger rules.
class RulesPage extends StatefulWidget {
  const RulesPage({super.key});
  @override
  State<RulesPage> createState() => _RulesPageState();
}

class _RulesPageState extends State<RulesPage> {
  Future<void> _open(BuildContext context, {UserRule? rule}) async {
    final isPro = context.read<ProCubit>().state.isPro;
    if (!isPro) {
      await showPaywall(context, reason: 'Custom trigger rules are a Pro feature.');
      return;
    }
    final bloc = context.read<PulseBloc>();
    await Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => BlocProvider(
        create: (_) => RuleBuilderCubit(bloc.engine.rules, existing: rule),
        child: const RuleBuilderPage(),
      ),
    ));
    bloc.add(const PulseRefreshed()); // evaluate the new rule immediately
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final engine = context.read<PulseBloc>().engine;
    final isPro = context.select((ProCubit c) => c.state.isPro);
    final rules = engine.rules.all();
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Rules')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _open(context),
        icon: Icon(isPro ? Icons.add_rounded : Icons.lock_rounded),
        label: const Text('New rule'),
      ),
      body: rules.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Text(
                    isPro
                        ? 'No rules yet. Combine time, battery, activity, network, weekday and place.'
                        : 'Build your own triggers, e.g. "Weekdays 17:00-19:00 + battery below 30% + near Office". Pro feature.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: cs.onSurfaceVariant)),
              ),
            )
          : ListView(padding: const EdgeInsets.only(bottom: 96), children: [
              for (final r in rules)
                Card.filled(
                  margin: const EdgeInsets.fromLTRB(16, 6, 16, 6),
                  child: ListTile(
                    onTap: () => _open(context, rule: r),
                    title: Text(r.name),
                    subtitle: Text(r.conditions.map((c) => c.describe()).join('  +  ')),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      Switch(
                        value: r.enabled,
                        onChanged: (v) {
                          engine.rules.setEnabled(r.id!, v);
                          setState(() {});
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete_outline_rounded),
                        onPressed: () {
                          engine.rules.delete(r.id!);
                          setState(() {});
                        },
                      ),
                    ]),
                  ),
                ),
            ]),
    );
  }
}
