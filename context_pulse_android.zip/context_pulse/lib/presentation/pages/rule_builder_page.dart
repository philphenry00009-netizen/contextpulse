import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:geolocator/geolocator.dart';
import '../../domain/entities.dart';
import '../../domain/rules.dart';
import '../bloc/rule_builder_cubit.dart';

class RuleBuilderPage extends StatelessWidget {
  const RuleBuilderPage({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<RuleBuilderCubit>();
    final cs = Theme.of(context).colorScheme;
    return BlocConsumer<RuleBuilderCubit, RuleDraft>(
      listenWhen: (a, b) => !a.saved && b.saved,
      listener: (context, s) => Navigator.of(context).pop(),
      builder: (context, d) => Scaffold(
        appBar: AppBar(title: Text(d.id == null ? 'New rule' : 'Edit rule'), actions: [
          TextButton(onPressed: cubit.save, child: const Text('Save')),
        ]),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          TextFormField(initialValue: d.name, onChanged: cubit.setName, decoration: const InputDecoration(labelText: 'Rule name')),
          const SizedBox(height: 12),
          TextFormField(initialValue: d.title, onChanged: cubit.setTitle, decoration: const InputDecoration(labelText: 'Card title')),
          const SizedBox(height: 12),
          TextFormField(initialValue: d.body, onChanged: cubit.setBody, maxLines: 2, decoration: const InputDecoration(labelText: 'Card details (optional)')),
          const SizedBox(height: 16),
          Text('Priority', style: Theme.of(context).textTheme.labelLarge),
          const SizedBox(height: 8),
          SegmentedButton<double>(
            segments: const [
              ButtonSegment(value: 45, label: Text('Low')),
              ButtonSegment(value: 65, label: Text('Medium')),
              ButtonSegment(value: 85, label: Text('High + notify')),
            ],
            selected: {d.priority >= 80 ? 85 : (d.priority >= 55 ? 65 : 45)},
            onSelectionChanged: (s) => cubit.setPriority(s.first),
          ),
          const SizedBox(height: 20),
          Text('When ALL of these are true', style: Theme.of(context).textTheme.labelLarge),
          const SizedBox(height: 8),
          for (var i = 0; i < d.conditions.length; i++)
            Card.outlined(
              child: ListTile(
                title: Text(d.conditions[i].describe()),
                trailing: IconButton(icon: const Icon(Icons.close_rounded), onPressed: () => cubit.removeCondition(i)),
              ),
            ),
          const SizedBox(height: 4),
          OutlinedButton.icon(
            onPressed: () => _addCondition(context, cubit),
            icon: const Icon(Icons.add_rounded),
            label: const Text('Add condition'),
          ),
          if (d.error != null)
            Padding(padding: const EdgeInsets.only(top: 12), child: Text(d.error!, style: TextStyle(color: cs.error))),
        ]),
      ),
    );
  }

  Future<void> _addCondition(BuildContext context, RuleBuilderCubit cubit) async {
    final kind = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          for (final e in const {
            'time': ('Time range', Icons.schedule_rounded),
            'weekday': ('Weekdays', Icons.calendar_view_week_rounded),
            'battery': ('Battery level', Icons.battery_std_rounded),
            'activity': ('Activity', Icons.directions_walk_rounded),
            'network': ('Network', Icons.wifi_rounded),
            'place': ('Place', Icons.place_rounded),
          }.entries)
            ListTile(leading: Icon(e.value.$2), title: Text(e.value.$1), onTap: () => Navigator.pop(context, e.key)),
        ]),
      ),
    );
    if (kind == null || !context.mounted) return;

    switch (kind) {
      case 'time':
        final a = await showTimePicker(context: context, initialTime: const TimeOfDay(hour: 17, minute: 0), helpText: 'From');
        if (a == null || !context.mounted) return;
        final b = await showTimePicker(context: context, initialTime: const TimeOfDay(hour: 19, minute: 0), helpText: 'Until');
        if (b == null) return;
        cubit.upsertCondition(TimeRangeCondition(a.hour * 60 + a.minute, b.hour * 60 + b.minute));
      case 'weekday':
        final days = await showDialog<Set<int>>(context: context, builder: (_) => const _WeekdayDialog());
        if (days != null) cubit.upsertCondition(WeekdayCondition(days));
      case 'battery':
        final c = await showDialog<BatteryCondition>(context: context, builder: (_) => const _BatteryDialog());
        if (c != null) cubit.upsertCondition(c);
      case 'activity':
        final a = await _pick<ActivityState>(context, 'Activity', [ActivityState.stationary, ActivityState.walking, ActivityState.driving]);
        if (a != null) cubit.upsertCondition(ActivityCondition(a));
      case 'network':
        final n = await _pick<NetworkState>(context, 'Network', NetworkState.values);
        if (n != null) cubit.upsertCondition(NetworkCondition(n));
      case 'place':
        final p = await showDialog<PlaceCondition>(context: context, builder: (_) => const _PlaceDialog());
        if (p != null) cubit.upsertCondition(p);
    }
  }

  Future<T?> _pick<T extends Enum>(BuildContext context, String title, List<T> values) => showDialog<T>(
        context: context,
        builder: (_) => SimpleDialog(title: Text(title), children: [
          for (final v in values) SimpleDialogOption(onPressed: () => Navigator.pop(context, v), child: Text(v.name)),
        ]),
      );
}

class _WeekdayDialog extends StatefulWidget {
  const _WeekdayDialog();
  @override
  State<_WeekdayDialog> createState() => _WeekdayDialogState();
}

class _WeekdayDialogState extends State<_WeekdayDialog> {
  final _sel = <int>{1, 2, 3, 4, 5};
  @override
  Widget build(BuildContext context) {
    const names = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    return AlertDialog(
      title: const Text('Weekdays'),
      content: Wrap(spacing: 6, children: [
        for (var d = 1; d <= 7; d++)
          FilterChip(label: Text(names[d - 1]), selected: _sel.contains(d), onSelected: (v) => setState(() => v ? _sel.add(d) : _sel.remove(d))),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(context, {..._sel}), child: const Text('OK')),
      ],
    );
  }
}

class _BatteryDialog extends StatefulWidget {
  const _BatteryDialog();
  @override
  State<_BatteryDialog> createState() => _BatteryDialogState();
}

class _BatteryDialogState extends State<_BatteryDialog> {
  bool _below = true;
  double _pct = 30;
  @override
  Widget build(BuildContext context) => AlertDialog(
        title: const Text('Battery'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          SegmentedButton<bool>(
            segments: const [ButtonSegment(value: true, label: Text('Below')), ButtonSegment(value: false, label: Text('At least'))],
            selected: {_below},
            onSelectionChanged: (s) => setState(() => _below = s.first),
          ),
          Slider(value: _pct, min: 5, max: 95, divisions: 18, label: '${_pct.round()}%', onChanged: (v) => setState(() => _pct = v)),
          Text('${_pct.round()}%'),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, BatteryCondition(below: _below, percent: _pct.round())), child: const Text('OK')),
        ],
      );
}

class _PlaceDialog extends StatefulWidget {
  const _PlaceDialog();
  @override
  State<_PlaceDialog> createState() => _PlaceDialogState();
}

class _PlaceDialogState extends State<_PlaceDialog> {
  final _label = TextEditingController(text: 'Here');
  double _radius = 150;
  bool _inside = true;
  Position? _pos;
  String? _err;
  bool _busy = false;

  @override
  void dispose() {
    _label.dispose();
    super.dispose();
  }

  Future<void> _locate() async {
    setState(() {
      _busy = true;
      _err = null;
    });
    try {
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
        throw 'Location permission denied';
      }
      _pos = await Geolocator.getCurrentPosition(
          locationSettings: const LocationSettings(accuracy: LocationAccuracy.low, timeLimit: Duration(seconds: 15)));
    } catch (e) {
      _err = '$e';
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
        title: const Text('Place'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: _label, decoration: const InputDecoration(labelText: 'Name (Home, Office...)')),
            const SizedBox(height: 12),
            FilledButton.tonalIcon(
              onPressed: _busy ? null : _locate,
              icon: const Icon(Icons.my_location_rounded),
              label: Text(_pos == null ? 'Use my current location' : 'Location set'),
            ),
            if (_err != null) Text(_err!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
            Slider(value: _radius, min: 50, max: 1000, divisions: 19, label: '${_radius.round()} m', onChanged: (v) => setState(() => _radius = v)),
            Text('Radius ${_radius.round()} m'),
            SegmentedButton<bool>(
              segments: const [ButtonSegment(value: true, label: Text('Near')), ButtonSegment(value: false, label: Text('Away'))],
              selected: {_inside},
              onSelectionChanged: (s) => setState(() => _inside = s.first),
            ),
            const SizedBox(height: 8),
            const Text('Place rules run from the cached last-known location. For background evaluation Android needs "Allow all the time" location access.',
                style: TextStyle(fontSize: 12)),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(
            onPressed: _pos == null || _label.text.trim().isEmpty
                ? null
                : () => Navigator.pop(context, PlaceCondition(label: _label.text.trim(), lat: _pos!.latitude, lng: _pos!.longitude, radiusM: _radius, inside: _inside)),
            child: const Text('OK'),
          ),
        ],
      );
}
