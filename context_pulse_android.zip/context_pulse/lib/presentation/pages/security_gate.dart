import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../security/integrity_guard.dart';

/// Runs the integrity check at startup. On a tampered/unofficial build it replaces the whole
/// UI with a modal that cannot be dismissed (back is blocked; the only action is Exit).
class SecurityGate extends StatefulWidget {
  const SecurityGate({super.key, required this.child});
  final Widget child;
  @override
  State<SecurityGate> createState() => _SecurityGateState();
}

class _SecurityGateState extends State<SecurityGate> {
  late final Future<IntegrityReport> _check = IntegrityGuard().check();

  @override
  Widget build(BuildContext context) => FutureBuilder<IntegrityReport>(
        future: _check,
        builder: (context, snap) {
          final r = snap.data;
          if (r != null && r.verdict == IntegrityVerdict.tampered) {
            return PopScope(
              canPop: false,
              child: Scaffold(
                body: Center(
                  child: AlertDialog(
                    icon: const Icon(Icons.gpp_bad_rounded),
                    title: const Text('Security Error'),
                    content: const Text('Unofficial version detected. Please install ContextPulse from the official Google Play Store.'),
                    actions: [TextButton(onPressed: () => SystemNavigator.pop(), child: const Text('Exit'))],
                  ),
                ),
              ),
            );
          }
          // While the check runs we show the app (fail-open) so startup is never blocked on network.
          return widget.child;
        },
      );
}
