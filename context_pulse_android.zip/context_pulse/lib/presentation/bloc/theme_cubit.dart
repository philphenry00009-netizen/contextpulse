import 'package:flutter_bloc/flutter_bloc.dart';
import '../../core/shared_flags.dart';

/// State = ARGB seed colour, or -1 for system dynamic colour (Monet). Only honoured for Pro users.
class ThemeCubit extends Cubit<int> {
  ThemeCubit() : super(-1);
  Future<void> load() async => emit(await SharedFlags.themeSeed());
  Future<void> setSeed(int argb) async {
    await SharedFlags.setThemeSeed(argb);
    emit(argb);
  }
}
