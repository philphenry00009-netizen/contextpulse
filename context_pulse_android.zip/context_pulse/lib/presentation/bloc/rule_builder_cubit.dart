import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../data/repositories.dart';
import '../../domain/rules.dart';

class RuleDraft extends Equatable {
  const RuleDraft({
    this.id,
    this.name = '',
    this.title = '',
    this.body = '',
    this.priority = 65,
    this.conditions = const [],
    this.error,
    this.saved = false,
  });
  final int? id;
  final String name, title, body;
  final double priority; // 45 low, 65 medium, 85 high (85 also triggers a notification)
  final List<RuleCondition> conditions;
  final String? error;
  final bool saved;

  RuleDraft copyWith({
    String? name, String? title, String? body, double? priority,
    List<RuleCondition>? conditions, String? error, bool clearError = false, bool? saved,
  }) =>
      RuleDraft(
        id: id,
        name: name ?? this.name,
        title: title ?? this.title,
        body: body ?? this.body,
        priority: priority ?? this.priority,
        conditions: conditions ?? this.conditions,
        error: clearError ? null : (error ?? this.error),
        saved: saved ?? this.saved,
      );

  @override
  List<Object?> get props => [id, name, title, body, priority, conditions, error, saved];
}

/// State machine for the rule builder screen: edit draft -> validate -> persist.
class RuleBuilderCubit extends Cubit<RuleDraft> {
  RuleBuilderCubit(this._repo, {UserRule? existing})
      : super(existing == null
            ? const RuleDraft()
            : RuleDraft(
                id: existing.id, name: existing.name, title: existing.title, body: existing.body,
                priority: existing.score, conditions: existing.conditions));

  final RuleRepository _repo;
  static const maxConditions = 6;

  void setName(String v) => emit(state.copyWith(name: v, clearError: true));
  void setTitle(String v) => emit(state.copyWith(title: v, clearError: true));
  void setBody(String v) => emit(state.copyWith(body: v));
  void setPriority(double v) => emit(state.copyWith(priority: v));

  /// One condition per kind keeps rules unambiguous: adding the same kind replaces it.
  void upsertCondition(RuleCondition c) {
    final list = [...state.conditions]..removeWhere((e) => e.runtimeType == c.runtimeType);
    if (list.length >= maxConditions) {
      emit(state.copyWith(error: 'At most $maxConditions conditions per rule'));
      return;
    }
    emit(state.copyWith(conditions: [...list, c], clearError: true));
  }

  void removeCondition(int i) =>
      emit(state.copyWith(conditions: [...state.conditions]..removeAt(i)));

  String? validate() {
    if (state.name.trim().isEmpty) return 'Give the rule a name';
    if (state.title.trim().isEmpty) return 'The card needs a title';
    if (state.conditions.isEmpty) return 'Add at least one condition';
    for (final c in state.conditions) {
      if (c is TimeRangeCondition && c.startMin == c.endMin) return 'Time range cannot be empty';
      if (c is WeekdayCondition && c.days.isEmpty) return 'Pick at least one weekday';
    }
    return null;
  }

  void save() {
    final err = validate();
    if (err != null) {
      emit(state.copyWith(error: err));
      return;
    }
    _repo.save(UserRule(
      id: state.id,
      name: state.name.trim(),
      title: state.title.trim(),
      body: state.body.trim(),
      conditions: state.conditions,
      score: state.priority,
    ));
    emit(state.copyWith(saved: true));
  }
}
