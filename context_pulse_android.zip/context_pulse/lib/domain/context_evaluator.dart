import 'dart:math';
import 'entities.dart';
import 'rules.dart';

/// Pure, deterministic rules engine: signals + habits -> ranked PulseCards.
/// No I/O, so it is trivially unit-testable and safe to run in a background isolate.
class ContextEvaluator {
  const ContextEvaluator();

  static const int maxCards = 5;
  static const double minScore = 20;
  static const double focusThreshold = 70;

  /// 0-100 "interruptibility": how good a moment this is to show the user things.
  double contextScore(ContextSignal s) {
    var v = 50.0;
    v += switch (s.activity) {
      ActivityState.stationary => 20,
      ActivityState.walking => 5,
      ActivityState.driving => -40,
      ActivityState.unknown => 0,
    };
    v += switch (s.network) {
      NetworkState.wifi => 10,
      NetworkState.cellular => 5,
      NetworkState.offline => -5,
    };
    if (s.hour >= 22 || s.hour < 6) v -= 25;
    final m = s.minutesToNextEvent;
    if (m != null && m >= 0 && m <= 15) v -= 15;
    if (s.batteryLevel < 15 && !s.isCharging) v -= 10;
    return v.clamp(0, 100).toDouble();
  }

  /// Returns at most [maxCards] cards, highest priority first.
  List<PulseCard> evaluate(ContextSignal s, List<Habit> habits,
      {List<UserRule> rules = const []}) {
    final cards = <PulseCard>[
      ..._custom(s, rules),
      ..._calendar(s),
      ..._habits(s, habits),
      ..._battery(s),
      ..._offline(s),
      ..._planning(s),
      ..._wrapUp(s),
    ];

    // Safety: while driving, de-prioritise everything except time-critical cards.
    final driving = s.activity == ActivityState.driving;
    final adjusted = cards.map((c) {
      if (driving && c.type != CardType.calendar && c.type != CardType.battery) {
        return c.copyWith(score: c.score * 0.3);
      }
      return c;
    }).where((c) => c.score >= minScore).toList()
      ..sort((a, b) => b.score.compareTo(a.score));

    // Focus profile: only high-priority cards get through.
    if (s.focusMode) adjusted.removeWhere((c) => c.score < focusThreshold);

    return adjusted.take(maxCards).toList();
  }

  // ---------------------------------------------------------------- rules
  /// Pro: user-authored rules. One card per rule per day (id includes the day).
  Iterable<PulseCard> _custom(ContextSignal s, List<UserRule> rules) sync* {
    for (final r in rules) {
      if (!r.matches(s)) continue;
      yield _card(s,
          id: 'rule:${r.id}:${dayKey(s.timestamp)}',
          type: CardType.custom,
          title: r.title,
          body: r.body,
          score: r.score,
          expires: s.timestamp.add(const Duration(hours: 2)),
          why: 'Rule "${r.name}": ${r.conditions.map((c) => c.describe()).join(' + ')}',
          payload: {'ruleId': r.id});
    }
  }

  Iterable<PulseCard> _calendar(ContextSignal s) sync* {
    for (final e in s.upcomingEvents) {
      final mins = e.start.difference(s.timestamp).inMinutes;
      final inProgress = !e.start.isAfter(s.timestamp) && e.end.isAfter(s.timestamp);
      final eid = 'event:${e.id}:${e.start.millisecondsSinceEpoch}';

      if (inProgress) {
        yield _card(s,
            id: eid,
            type: CardType.calendar,
            title: e.title,
            body: 'In progress until ${_hm(e.end)}',
            score: 40,
            expires: e.end,
            why: 'Event is happening now',
            payload: {'eventId': e.id});
        continue;
      }
      if (mins < 0 || mins > 90) continue;

      var score = 55 + (90 - mins) * 0.4;
      if (mins <= 15) score += 10;
      final parts = <String>['Starts in $mins min (${_hm(e.start)})'];
      final why = <String>['Event in $mins min'];
      final loc = e.location;
      if (loc != null && loc.isNotEmpty) {
        parts.add('at $loc');
        if (s.activity == ActivityState.stationary && mins <= 40) {
          score += 8;
          parts.add('- time to head out');
          why.add('you are stationary');
        }
      }
      if (s.batteryLevel <= 20 && !s.isCharging && mins <= 60) {
        score += 8;
        parts.add('(battery ${s.batteryLevel}%)');
        why.add('battery low');
      }
      yield _card(s,
          id: eid,
          type: CardType.calendar,
          title: e.title,
          body: parts.join(' '),
          score: score,
          expires: e.start.add(const Duration(minutes: 5)),
          why: why.join(' + '),
          payload: {'eventId': e.id});
    }
  }

  Iterable<PulseCard> _habits(ContextSignal s, List<Habit> habits) sync* {
    final t = s.timestamp;
    for (final h in habits) {
      if (h.lastDone != null && dayKey(h.lastDone!) == dayKey(t)) continue;
      final start = DateTime(t.year, t.month, t.day, h.hour);
      final opens = start.subtract(const Duration(minutes: 30));
      final closes = start.add(Duration(minutes: h.windowMin));
      if (t.isBefore(opens) || t.isAfter(closes)) continue;

      final late = t.difference(start).inMinutes; // negative = early
      var score = 42.0;
      if (late > 0) score += 8 + min(15.0, late / 8);
      score += switch (s.activity) {
        ActivityState.stationary => 5,
        ActivityState.walking => -5,
        _ => 0,
      };
      yield _card(s,
          id: 'habit:${h.id}:${dayKey(t)}',
          type: CardType.habit,
          title: h.title,
          body: late > 0 ? 'Due ${late}m ago - quick check-in?' : 'Coming up around ${_hm(start)}',
          score: score,
          expires: closes,
          why: 'Habit window ${_hm(start)}-${_hm(closes)}, not done today',
          payload: {'habitId': h.id});
    }
  }

  Iterable<PulseCard> _battery(ContextSignal s) sync* {
    if (s.isCharging || s.batteryLevel > 20) return;
    final critical = s.batteryLevel <= 10;
    final score = min(95.0, 70 + (20 - s.batteryLevel) * 1.5);
    yield _card(s,
        id: 'battery:${dayKey(s.timestamp)}:${critical ? 'critical' : 'low'}',
        type: CardType.battery,
        title: 'Battery at ${s.batteryLevel}%',
        body: critical
            ? 'Critical - plug in now or enable battery saver.'
            : 'Plug in soon, or enable battery saver.',
        score: score,
        expires: s.timestamp.add(const Duration(hours: 2)),
        why: 'Battery <= 20% and not charging');
  }

  Iterable<PulseCard> _offline(ContextSignal s) sync* {
    if (s.network != NetworkState.offline) return;
    yield _card(s,
        id: 'offline:${dayKey(s.timestamp)}:${s.hour}',
        type: CardType.offline,
        title: "You're offline",
        body: 'Everything keeps working. Queued items sync when you reconnect.',
        score: 30,
        expires: s.timestamp.add(const Duration(hours: 1)),
        why: 'No network connection');
  }

  Iterable<PulseCard> _planning(ContextSignal s) sync* {
    if (s.hour < 5 || s.hour >= 10) return;
    final t = s.timestamp;
    final endOfDay = DateTime(t.year, t.month, t.day, 23, 59);
    final today = s.upcomingEvents
        .where((e) => e.start.isAfter(t) && e.start.isBefore(endOfDay))
        .toList()
      ..sort((a, b) => a.start.compareTo(b.start));
    if (today.isEmpty) return;
    yield _card(s,
        id: 'planning:${dayKey(t)}',
        type: CardType.planning,
        title: 'Plan your day',
        body: '${today.length} event${today.length == 1 ? '' : 's'} today, first at ${_hm(today.first.start)}.',
        score: 38,
        expires: DateTime(t.year, t.month, t.day, 10),
        why: 'Morning + events on your calendar');
  }

  Iterable<PulseCard> _wrapUp(ContextSignal s) sync* {
    if (s.hour < 20 || s.hour >= 23) return;
    final t = s.timestamp;
    yield _card(s,
        id: 'wrapup:${dayKey(t)}',
        type: CardType.wrapUp,
        title: "Log today's spending",
        body: 'Take 10 seconds to log expenses or a note before the day ends.',
        score: 36,
        expires: DateTime(t.year, t.month, t.day, 23),
        why: 'Evening wrap-up window');
  }

  // ---------------------------------------------------------------- helpers
  PulseCard _card(
    ContextSignal s, {
    required String id,
    required CardType type,
    required String title,
    required String body,
    required double score,
    required DateTime expires,
    required String why,
    Map<String, Object?> payload = const {},
  }) =>
      PulseCard(
        id: id,
        type: type,
        title: title,
        body: body,
        score: score.clamp(0, 100).toDouble(),
        createdAt: s.timestamp,
        expiresAt: expires,
        payload: {...payload, 'why': why},
      );

  static String _hm(DateTime d) =>
      '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
}
