import 'dart:convert';
import 'dart:math';
import 'entities.dart';

/// A single AND-ed predicate in a user-defined trigger rule.
/// Example rule: "Weekdays 17:00-19:00 + battery below 30% + near Office" -> card.
sealed class RuleCondition {
  const RuleCondition();
  bool matches(ContextSignal s);
  String describe();
  Map<String, Object?> toJson();

  static RuleCondition fromJson(Map<String, Object?> j) => switch (j['t']) {
        'time' => TimeRangeCondition(j['start'] as int, j['end'] as int),
        'battery' => BatteryCondition(below: j['below'] as bool, percent: j['pct'] as int),
        'activity' => ActivityCondition(enumByName(ActivityState.values, j['v'], ActivityState.unknown)),
        'network' => NetworkCondition(enumByName(NetworkState.values, j['v'], NetworkState.offline)),
        'weekday' => WeekdayCondition({for (final d in (j['days'] as List)) d as int}),
        'place' => PlaceCondition(
            label: j['label'] as String,
            lat: (j['lat'] as num).toDouble(),
            lng: (j['lng'] as num).toDouble(),
            radiusM: (j['r'] as num).toDouble(),
            inside: j['in'] as bool),
        _ => throw FormatException('Unknown condition ${j['t']}'),
      };
}

class TimeRangeCondition extends RuleCondition {
  const TimeRangeCondition(this.startMin, this.endMin);
  final int startMin, endMin; // minutes since midnight; start > end means overnight

  @override
  bool matches(ContextSignal s) {
    final m = s.timestamp.hour * 60 + s.timestamp.minute;
    return startMin <= endMin ? (m >= startMin && m < endMin) : (m >= startMin || m < endMin);
  }

  static String _f(int m) =>
      '${(m ~/ 60).toString().padLeft(2, '0')}:${(m % 60).toString().padLeft(2, '0')}';
  @override
  String describe() => 'Time ${_f(startMin)}-${_f(endMin)}';
  @override
  Map<String, Object?> toJson() => {'t': 'time', 'start': startMin, 'end': endMin};
}

class BatteryCondition extends RuleCondition {
  const BatteryCondition({required this.below, required this.percent});
  final bool below;
  final int percent;
  @override
  bool matches(ContextSignal s) =>
      below ? (s.batteryLevel < percent && !s.isCharging) : s.batteryLevel >= percent;
  @override
  String describe() => below ? 'Battery below $percent% (not charging)' : 'Battery at least $percent%';
  @override
  Map<String, Object?> toJson() => {'t': 'battery', 'below': below, 'pct': percent};
}

class ActivityCondition extends RuleCondition {
  const ActivityCondition(this.activity);
  final ActivityState activity;
  @override
  bool matches(ContextSignal s) => s.activity == activity;
  @override
  String describe() => 'Activity is ${activity.name}';
  @override
  Map<String, Object?> toJson() => {'t': 'activity', 'v': activity.name};
}

class NetworkCondition extends RuleCondition {
  const NetworkCondition(this.network);
  final NetworkState network;
  @override
  bool matches(ContextSignal s) => s.network == network;
  @override
  String describe() => 'Network is ${network.name}';
  @override
  Map<String, Object?> toJson() => {'t': 'network', 'v': network.name};
}

class WeekdayCondition extends RuleCondition {
  const WeekdayCondition(this.days); // DateTime.monday(1) .. sunday(7)
  final Set<int> days;
  @override
  bool matches(ContextSignal s) => days.contains(s.timestamp.weekday);
  @override
  String describe() {
    const n = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    final l = days.toList()..sort();
    return 'On ${l.map((d) => n[d - 1]).join(', ')}';
  }

  @override
  Map<String, Object?> toJson() => {'t': 'weekday', 'days': days.toList()..sort()};
}

class PlaceCondition extends RuleCondition {
  const PlaceCondition(
      {required this.label,
      required this.lat,
      required this.lng,
      required this.radiusM,
      required this.inside});
  final String label;
  final double lat, lng, radiusM;
  final bool inside; // true = within radius, false = outside radius

  @override
  bool matches(ContextSignal s) {
    final la = s.latitude, ln = s.longitude;
    if (la == null || ln == null) return false; // unknown location never matches
    final d = _haversineM(lat, lng, la, ln);
    return inside ? d <= radiusM : d > radiusM;
  }

  static double _haversineM(double la1, double lo1, double la2, double lo2) {
    const r = 6371000.0;
    double rad(double d) => d * pi / 180;
    final dLa = rad(la2 - la1), dLo = rad(lo2 - lo1);
    final a = pow(sin(dLa / 2), 2) + cos(rad(la1)) * cos(rad(la2)) * pow(sin(dLo / 2), 2);
    return 2 * r * asin(sqrt(a));
  }

  @override
  String describe() => '${inside ? 'Near' : 'Away from'} $label (${radiusM.round()} m)';
  @override
  Map<String, Object?> toJson() =>
      {'t': 'place', 'label': label, 'lat': lat, 'lng': lng, 'r': radiusM, 'in': inside};
}

/// A user-authored rule that emits a PulseCard when ALL conditions match.
class UserRule {
  const UserRule({
    this.id,
    required this.name,
    required this.title,
    required this.body,
    required this.conditions,
    this.score = 65,
    this.enabled = true,
  });

  final int? id;
  final String name;
  final String title;
  final String body;
  final List<RuleCondition> conditions;
  final double score;
  final bool enabled;

  bool matches(ContextSignal s) =>
      enabled && conditions.isNotEmpty && conditions.every((c) => c.matches(s));

  bool get needsLocation => conditions.any((c) => c is PlaceCondition);

  String conditionsJson() => jsonEncode(conditions.map((c) => c.toJson()).toList());

  static List<RuleCondition> parseConditions(String json) => [
        for (final j in jsonDecode(json) as List)
          RuleCondition.fromJson(Map<String, Object?>.from(j as Map))
      ];

  factory UserRule.fromMap(Map<String, Object?> m) => UserRule(
        id: m['id'] as int,
        name: m['name'] as String,
        title: m['title'] as String,
        body: (m['body'] as String?) ?? '',
        conditions: parseConditions(m['conditions'] as String),
        score: (m['score'] as num).toDouble(),
        enabled: (m['enabled'] as int) == 1,
      );
}
