import 'package:flutter/material.dart';

/// Material 3 theme factory. Free tier: Monet dynamic colour from the wallpaper
/// (Android 12+). Pro tier: user-chosen seed colour.
class AppTheme {
  static const fallbackSeed = Color(0xFF00BCD4); // used when dynamic colour is unavailable

  static const proSeeds = <String, Color>{
    'Cyan': Color(0xFF00BCD4),
    'Indigo': Color(0xFF5C6BC0),
    'Emerald': Color(0xFF2E7D32),
    'Amber': Color(0xFFFFA000),
    'Rose': Color(0xFFD81B60),
    'Violet': Color(0xFF7E57C2),
  };

  static ThemeData build(ColorScheme scheme) => ThemeData(
        useMaterial3: true,
        colorScheme: scheme,
        // M3 ink ripple / stretch overscroll are defaults on Android with useMaterial3.
        pageTransitionsTheme: const PageTransitionsTheme(builders: {
          // Predictive back (Android 13+; falls back to zoom on 12 and below).
          TargetPlatform.android: PredictiveBackPageTransitionsBuilder(),
        }),
        cardTheme: CardThemeData(
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
        ),
        snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
      );

  static Color scoreColor(ColorScheme cs, double s) =>
      s >= 75 ? cs.primary : (s >= 50 ? cs.tertiary : cs.outline);
}
