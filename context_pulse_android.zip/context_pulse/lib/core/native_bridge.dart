import 'package:flutter/services.dart';

/// Thin typed wrapper over the Kotlin side (MainActivity.kt). Only available in the
/// UI isolate (the WorkManager isolate cannot reach it), so anything the background
/// worker needs is exchanged through SharedFlags instead. Every call is failure-tolerant.
class NativeBridge {
  static const _c = MethodChannel('dev.contextpulse/native');

  static Future<T?> _call<T>(String m, [Object? args]) async {
    try {
      return await _c.invokeMethod<T>(m, args);
    } catch (_) {
      return null;
    }
  }

  // --- Activity Recognition (Transition API receiver) ---
  static Future<void> startActivityUpdates() => _call('startActivityUpdates');


  // --- Security ---
  static Future<String?> integrityToken(String nonce, int projectNumber) =>
      _call<String>('integrityToken', {'nonce': nonce, 'project': projectNumber});
  static Future<String?> packageName() => _call<String>('packageName');
  static Future<String?> signingCertSha256() => _call<String>('signingCertSha256');
  static Future<String?> installerPackage() => _call<String>('installerPackage');
  static Future<bool> isRooted() async => (await _call<bool>('isRooted')) ?? false;
  static Future<bool> verifyPlaySignature(String keyB64, String json, String sig) async =>
      (await _call<bool>('verifyPlaySignature', {'key': keyB64, 'json': json, 'sig': sig})) ?? false;

  // --- Battery optimisation whitelist ---
  static Future<bool> isIgnoringBatteryOptimizations() async =>
      (await _call<bool>('isIgnoringBatteryOptimizations')) ?? false;
  static Future<void> requestIgnoreBatteryOptimizations() =>
      _call('requestIgnoreBatteryOptimizations');
}
