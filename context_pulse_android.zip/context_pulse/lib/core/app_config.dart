import 'package:flutter/foundation.dart';

/// Single place for build-time configuration. Fill these in before release.
class AppConfig {
  // --- Play Billing ---------------------------------------------------------
  static const proMonthlyId = 'pro_monthly'; // $1.99 / month  (Play Console subscription)
  static const proYearlyId = 'pro_yearly'; //  $14.99 / year
  static const proIds = {proMonthlyId, proYearlyId};

  /// Play Console > Monetization setup > "Licensing" Base64 RSA public key.
  /// It is a PUBLIC key, safe to ship. Used to verify purchase signatures offline.
  static const playLicenseKeyBase64 = 'REPLACE_WITH_PLAY_CONSOLE_LICENSE_KEY';

  /// How long a cached, signature-valid receipt keeps Pro unlocked without
  /// re-confirmation from Play (offline grace window).
  static const proGrace = Duration(days: 7);

  // --- Security -------------------------------------------------------------
  /// Google Cloud project number linked to Play Integrity API (Play Console > App integrity).
  static const cloudProjectNumber = 0; // REPLACE
  /// Your verifier endpoint (see server/verify_integrity.py). Empty = local checks only.
  static const integrityVerifierUrl = '';
  /// SHA-256 of your *Play App Signing* certificate (Play Console > App integrity), hex, no colons.
  static const expectedSigningCertSha256 = ''; // REPLACE
  /// Enforce only in release builds so `flutter run` keeps working.
  static bool get enforceSecurity => kReleaseMode && expectedSigningCertSha256.isNotEmpty;
  static const blockOnRoot = false; // policy hook: rooted devices are flagged, not blocked

  // --- Product limits -------------------------------------------------------
  static const freeDailyCardQuota = 5;
}
