import 'package:shared_preferences/shared_preferences.dart';

/// Tiny cross-process mailbox between native Kotlin (tiles, receivers) and Dart,
/// readable from BOTH the UI isolate and the WorkManager isolate. Kotlin writes the same
/// "FlutterSharedPreferences" file using the "flutter." key prefix.
class SharedFlags {
  static Future<SharedPreferences> _p() async {
    final p = await SharedPreferences.getInstance();
    await p.reload(); // pick up values written natively since last read
    return p;
  }

  // Written by ActivityTransitionReceiver.kt
  static Future<(String?, DateTime?)> lastActivity() async {
    final p = await _p();
    final t = p.getInt('cp_activity_ts');
    return (p.getString('cp_activity_type'), t == null ? null : DateTime.fromMillisecondsSinceEpoch(t));
  }

  // Toggled by FocusTileService.kt, also settable from the app UI.
  static Future<bool> focusOn() async => (await _p()).getBool('cp_focus') ?? false;
  static Future<void> setFocus(bool v) async => (await _p()).setBool('cp_focus', v);

  // Written by Dart after receipt verification; read by the native tiles to gate Pro features.
  static Future<void> setPro(bool v) async => (await _p()).setBool('cp_pro', v);

  // Written by ScanTileService.kt / notification taps; consumed once by the UI.
  static Future<String?> consumeLaunchAction() async {
    final p = await _p();
    final a = p.getString('cp_launch_action');
    if (a != null) await p.remove('cp_launch_action');
    return a;
  }

  // Theme choices (Pro: custom seed). -1 = system dynamic colour.
  static Future<int> themeSeed() async => (await _p()).getInt('cp_theme_seed') ?? -1;
  static Future<void> setThemeSeed(int v) async => (await _p()).setInt('cp_theme_seed', v);
}
