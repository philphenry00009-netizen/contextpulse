import 'dart:math';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Backed by Android Keystore (AES key wrapping via EncryptedSharedPreferences).
/// Holds the DB key, API key, license receipt and security verdicts: never the SQL DB.
class SecureStore {
  static const _s = FlutterSecureStorage(
      aOptions: AndroidOptions(encryptedSharedPreferences: true));

  Future<String?> read(String k) => _s.read(key: k);
  Future<void> write(String k, String v) => _s.write(key: k, value: v);
  Future<void> delete(String k) => _s.delete(key: k);

  /// 256-bit SQLCipher key (64 hex chars), generated once with a CSPRNG.
  Future<String> dbKey() async {
    var k = await _s.read(key: 'db_key');
    if (k == null) {
      final r = Random.secure();
      k = List.generate(32, (_) => r.nextInt(256).toRadixString(16).padLeft(2, '0')).join();
      await _s.write(key: 'db_key', value: k);
    }
    return k;
  }

  Future<bool> aiOptIn() async => (await read('ai_opt_in')) == '1';
  Future<void> setAiOptIn(bool v) => write('ai_opt_in', v ? '1' : '0');
  Future<String?> aiKey() => read('ai_key');
  Future<void> setAiKey(String v) => write('ai_key', v.trim());
}
