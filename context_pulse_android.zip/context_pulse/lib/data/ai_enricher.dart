import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import '../core/secure_store.dart';
import 'repositories.dart';

/// OPTIONAL. Off unless the user opts in AND supplies their own Gemini API key.
/// Sends only a card's generic title/body (never raw signals, never calendar cards)
/// and asks for structured JSON back.
class AiEnricher {
  AiEnricher(this._store, this._cards, this._queue, {http.Client? client})
      : _client = client ?? http.Client();

  final SecureStore _store;
  final PulseRepository _cards;
  final EnrichQueueRepository _queue;
  final http.Client _client;

  // Model names change over time; update to a current Gemini Flash model if needed.
  static const model = 'gemini-2.0-flash';

  /// Drains up to [max] queued cards. Stops quietly when offline (queue persists).
  Future<int> processQueue({int max = 3}) async {
    if (!await _store.aiOptIn()) return 0;
    final key = await _store.aiKey();
    if (key == null || key.isEmpty) return 0;

    var done = 0;
    for (final id in _queue.pending(limit: max)) {
      final card = _cards.get(id);
      if (card == null || card.userEdited || card.aiEnriched) {
        _queue.remove(id);
        continue;
      }
      try {
        final uri = Uri.https('generativelanguage.googleapis.com',
            '/v1beta/models/$model:generateContent', {'key': key});
        final prompt = 'Rewrite this notification card to be warmer and clearer. '
            'Do not add facts. Return ONLY JSON: {"title": string (max 40 chars), '
            '"body": string (max 100 chars)}.\n'
            '${jsonEncode({'type': card.type.name, 'title': card.title, 'body': card.body})}';
        final res = await _client
            .post(uri,
                headers: {'Content-Type': 'application/json'},
                body: jsonEncode({
                  'contents': [
                    {'parts': [{'text': prompt}]}
                  ],
                  'generationConfig': {'responseMimeType': 'application/json'},
                }))
            .timeout(const Duration(seconds: 15));
        if (res.statusCode == 429 || res.statusCode >= 500) break; // retry later
        if (res.statusCode != 200) {
          _cards.markEnriched(id, 2); // give up on this card
          _queue.remove(id);
          continue;
        }
        final text = (jsonDecode(res.body)['candidates'][0]['content']['parts'][0]['text']) as String;
        final j = jsonDecode(text) as Map<String, dynamic>;
        final t = (j['title'] as String?)?.trim() ?? '';
        final b = (j['body'] as String?)?.trim() ?? '';
        if (t.isEmpty || t.length > 60 || b.length > 140) {
          _cards.markEnriched(id, 2);
        } else {
          _cards.markEnriched(id, 1, title: t, body: b);
          done++;
        }
        _queue.remove(id);
      } on SocketException {
        break;
      } on TimeoutException {
        break;
      } on http.ClientException {
        break;
      } catch (e) {
        debugPrint('AI enrich failed for $id: $e');
        _cards.markEnriched(id, 2);
        _queue.remove(id);
      }
    }
    return done;
  }
}
