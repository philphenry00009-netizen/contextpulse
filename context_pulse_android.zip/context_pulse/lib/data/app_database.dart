import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqlcipher_flutter_libs/sqlcipher_flutter_libs.dart';
import 'package:sqlite3/open.dart' as sqlite_open;
import 'package:sqlite3/sqlite3.dart';
import '../core/secure_store.dart';

/// Encrypted (SQLCipher, AES-256) on-device database.
/// One connection per isolate; WAL + busy_timeout lets the UI isolate and the
/// background worker share the file safely.
class AppDatabase {
  AppDatabase._(this.raw);
  final Database raw;
  static AppDatabase? _instance;

  static Future<AppDatabase> connect() async {
    if (_instance != null) return _instance!;
    if (Platform.isAndroid) {
      await applyWorkaroundToOpenSqlCipherOnOldAndroidVersions();
      sqlite_open.open
          .overrideFor(sqlite_open.OperatingSystem.android, openCipherOnAndroid);
    }
    final dir = await getApplicationSupportDirectory();
    final path = p.join(dir.path, 'contextpulse.db');
    final key = await SecureStore().dbKey();

    final db = sqlite3.open(path);
    // Refuse to run if SQLCipher is not actually linked (would silently be plaintext).
    final v = db.select('PRAGMA cipher_version;');
    if (v.isEmpty || v.first.values.first == null) {
      db.dispose();
      throw StateError('SQLCipher unavailable; refusing to open an unencrypted DB.');
    }
    db.execute("PRAGMA key = \"x'$key'\";");
    db.select('SELECT count(*) FROM sqlite_master;'); // throws if the key is wrong
    db.execute('PRAGMA journal_mode = WAL;');
    db.execute('PRAGMA busy_timeout = 5000;');
    db.execute('PRAGMA foreign_keys = ON;');
    _migrate(db);
    return _instance = AppDatabase._(db);
  }

  static void _migrate(Database db) {
    final version = db.select('PRAGMA user_version;').first.values.first as int;
    if (version < 1) {
      inTransaction(db, () {
        db.execute('''
CREATE TABLE signals(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, activity TEXT,
  network TEXT, battery INTEGER, charging INTEGER, next_event_min INTEGER,
  context_score REAL);
CREATE INDEX idx_signals_ts ON signals(ts);
CREATE TABLE events(
  id TEXT PRIMARY KEY, title TEXT, start_ms INTEGER NOT NULL,
  end_ms INTEGER NOT NULL, location TEXT);
CREATE TABLE habits(
  id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, hour INTEGER NOT NULL,
  window_min INTEGER NOT NULL DEFAULT 120, last_done_ms INTEGER);
CREATE TABLE cards(
  id TEXT PRIMARY KEY, type TEXT NOT NULL, title TEXT NOT NULL, body TEXT,
  score REAL NOT NULL, created_ms INTEGER NOT NULL, expires_ms INTEGER NOT NULL,
  last_seen_ms INTEGER NOT NULL, snoozed_until_ms INTEGER,
  status TEXT NOT NULL DEFAULT 'active', payload TEXT,
  ai_enriched INTEGER NOT NULL DEFAULT 0, user_edited INTEGER NOT NULL DEFAULT 0);
CREATE INDEX idx_cards_status ON cards(status, score);
CREATE TABLE actions(
  id INTEGER PRIMARY KEY AUTOINCREMENT, card_id TEXT, kind TEXT NOT NULL,
  note TEXT, amount REAL, created_ms INTEGER NOT NULL);
CREATE TABLE enrich_queue(card_id TEXT PRIMARY KEY, queued_ms INTEGER NOT NULL);
PRAGMA user_version = 1;''');
      });
    }
    if (version < 2) {
      inTransaction(db, () {
        db.execute('''
ALTER TABLE cards ADD COLUMN notified INTEGER NOT NULL DEFAULT 0;
CREATE TABLE rules(
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, title TEXT NOT NULL,
  body TEXT, conditions TEXT NOT NULL, score REAL NOT NULL DEFAULT 65,
  enabled INTEGER NOT NULL DEFAULT 1);
PRAGMA user_version = 2;''');
      });
    }
  }
}

/// Runs [body] in a transaction; rolls back on any error.
T inTransaction<T>(Database db, T Function() body) {
  db.execute('BEGIN IMMEDIATE');
  try {
    final r = body();
    db.execute('COMMIT');
    return r;
  } catch (_) {
    db.execute('ROLLBACK');
    rethrow;
  }
}
