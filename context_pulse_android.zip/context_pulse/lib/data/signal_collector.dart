import 'dart:math';
import 'package:battery_plus/battery_plus.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:device_calendar/device_calendar.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_activity_recognition/flutter_activity_recognition.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:geolocator/geolocator.dart';
import '../core/shared_flags.dart';
import 'package:sensors_plus/sensors_plus.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import '../domain/entities.dart';

/// Reads the five ambient signals. Every probe is wrapped so one failure
/// (denied permission, missing sensor) never blocks the others.
class SignalCollector {
  SignalCollector({Battery? battery, Connectivity? connectivity, DeviceCalendarPlugin? calendar})
      : _battery = battery ?? Battery(),
        _connectivity = connectivity ?? Connectivity(),
        _calendar = calendar ?? DeviceCalendarPlugin();

  final Battery _battery;
  final Connectivity _connectivity;
  final DeviceCalendarPlugin _calendar;
  static bool _tzReady = false;

  /// [wantLocation]: only true when an enabled Pro rule has a place condition, so
  /// location is never touched otherwise. Uses the cached last-known fix (no GPS spin-up).
  Future<ContextSignal> collect({DateTime? now, bool wantLocation = false}) async {
    final t = now ?? DateTime.now();
    final focusF = SharedFlags.focusOn();
    final posF = wantLocation ? _position() : Future<Position?>.value(null);
    // Start all probes concurrently; total latency ~= the 2 s accelerometer window.
    final activityF = _activity();
    final networkF = _network();
    final batteryF = _batteryInfo();
    final eventsF = _events(t);
    final battery = await batteryF;
    final pos = await posF;
    return ContextSignal(
      latitude: pos?.latitude,
      longitude: pos?.longitude,
      focusMode: await focusF,
      timestamp: t,
      activity: await activityF,
      network: await networkF,
      batteryLevel: battery.$1,
      isCharging: battery.$2,
      upcomingEvents: await eventsF,
    );
  }

  Future<Position?> _position() async {
    try {
      final perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) return null;
      return await Geolocator.getLastKnownPosition();
    } catch (_) {
      return null;
    }
  }

  Future<NetworkState> _network() async {
    try {
      final r = await _connectivity.checkConnectivity();
      if (r.contains(ConnectivityResult.wifi) || r.contains(ConnectivityResult.ethernet)) {
        return NetworkState.wifi;
      }
      if (r.contains(ConnectivityResult.mobile) ||
          r.contains(ConnectivityResult.vpn) ||
          r.contains(ConnectivityResult.other)) {
        return NetworkState.cellular;
      }
      return NetworkState.offline;
    } catch (_) {
      return NetworkState.offline;
    }
  }

  Future<(int, bool)> _batteryInfo() async {
    try {
      final level = await _battery.batteryLevel;
      final state = await _battery.batteryState;
      return (level, state == BatteryState.charging || state == BatteryState.full);
    } catch (_) {
      return (100, false);
    }
  }

  /// Prefers OS activity recognition (Google Play Services / CoreMotion); falls back
  /// to a 2-second accelerometer variance check when unavailable or denied.
  Future<ActivityState> _activity() async {
    // 1) Event-driven Transition API result written by the native receiver (zero polling).
    try {
      final (type, at) = await SharedFlags.lastActivity();
      if (type != null && at != null && DateTime.now().difference(at) < const Duration(hours: 6)) {
        switch (type) {
          case 'IN_VEHICLE':
            return ActivityState.driving;
          case 'WALKING':
          case 'RUNNING':
          case 'ON_BICYCLE':
            return ActivityState.walking;
          case 'STILL':
            return ActivityState.stationary;
        }
      }
    } catch (_) {}
    // 2) Direct plugin read, then 3) accelerometer fallback.
    try {
      final ar = FlutterActivityRecognition.instance;
      if (await ar.checkPermission() == ActivityPermission.GRANTED) {
        final a = await ar.activityStream.first.timeout(const Duration(seconds: 3));
        switch (a.type) {
          case ActivityType.IN_VEHICLE:
            return ActivityState.driving;
          case ActivityType.WALKING:
          case ActivityType.RUNNING:
          case ActivityType.ON_BICYCLE:
            return ActivityState.walking;
          case ActivityType.STILL:
            return ActivityState.stationary;
          default:
            break;
        }
      }
    } catch (_) {}
    return _accelerometerHeuristic();
  }

  Future<ActivityState> _accelerometerHeuristic() async {
    try {
      final mags = <double>[];
      final sub = accelerometerEventStream(samplingPeriod: SensorInterval.normalInterval)
          .listen((e) => mags.add(sqrt(e.x * e.x + e.y * e.y + e.z * e.z)));
      await Future<void>.delayed(const Duration(seconds: 2));
      await sub.cancel();
      if (mags.length < 5) return ActivityState.unknown;
      final mean = mags.reduce((a, b) => a + b) / mags.length;
      final variance =
          mags.map((m) => (m - mean) * (m - mean)).reduce((a, b) => a + b) / mags.length;
      final std = sqrt(variance);
      if (std < 0.35) return ActivityState.stationary;
      if (std >= 0.8) return ActivityState.walking;
      return ActivityState.unknown; // ambiguous band (vehicle vibration, hand jitter)
    } catch (_) {
      return ActivityState.unknown;
    }
  }

  Future<void> _ensureTz() async {
    if (_tzReady) return;
    tzdata.initializeTimeZones();
    final name = await FlutterTimezone.getLocalTimezone();
    tz.setLocalLocation(tz.getLocation(name));
    _tzReady = true;
  }

  /// Read-only: never writes to the calendar.
  Future<List<ScheduleEvent>> _events(DateTime now) async {
    try {
      await _ensureTz();
      final has = await _calendar.hasPermissions();
      if (!(has.isSuccess && (has.data ?? false))) return const [];
      final cals = await _calendar.retrieveCalendars();
      final out = <ScheduleEvent>[];
      final from = now.subtract(const Duration(hours: 2));
      final to = now.add(const Duration(hours: 24));
      for (final c in cals.data ?? <Calendar>[]) {
        final cid = c.id;
        if (cid == null) continue;
        final res = await _calendar.retrieveEvents(
            cid, RetrieveEventsParams(startDate: from, endDate: to));
        for (final e in res.data ?? <Event>[]) {
          final s = e.start, en = e.end;
          if (s == null || en == null || e.allDay == true) continue;
          out.add(ScheduleEvent(
            id: e.eventId ?? '$cid-${s.millisecondsSinceEpoch}',
            title: (e.title ?? '(no title)').trim(),
            start: DateTime.fromMillisecondsSinceEpoch(s.millisecondsSinceEpoch),
            end: DateTime.fromMillisecondsSinceEpoch(en.millisecondsSinceEpoch),
            location: e.location,
          ));
        }
      }
      out.sort((a, b) => a.start.compareTo(b.start));
      return out;
    } catch (e) {
      debugPrint('calendar read failed: $e');
      return const [];
    }
  }
}
