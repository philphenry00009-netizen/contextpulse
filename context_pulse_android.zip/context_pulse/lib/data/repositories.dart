import 'dart:convert';
import 'package:sqlite3/sqlite3.dart';
import '../domain/context_evaluator.dart';
import '../domain/entities.dart';
import '../domain/rules.dart';
import 'app_database.dart';

int _ms(DateTime d) => d.millisecondsSinceEpoch;
Map<String, Object?> _m(Row r) => Map<String, Object?>.from(r);

// ============================================================== Pulse cards
class PulseRepository {
  PulseRepository(this._db);
  final Database _db;

  /// Insert new cards or refresh score/expiry of existing ones. Status
  /// (completed/dismissed) and user/AI-edited text are never overwritten.
  void upsertAll(List<PulseCard> cards, DateTime now) {
    if (cards.isEmpty) return;
    inTransaction(_db, () {
      final st = _db.prepare('''
INSERT INTO cards(id,type,title,body,score,created_ms,expires_ms,last_seen_ms,status,payload)
VALUES(?,?,?,?,?,?,?,?, 'active', ?)
ON CONFLICT(id) DO UPDATE SET
  score=excluded.score, expires_ms=excluded.expires_ms, last_seen_ms=excluded.last_seen_ms,
  title=CASE WHEN cards.user_edited=1 OR cards.ai_enriched=1 THEN cards.title ELSE excluded.title END,
  body =CASE WHEN cards.user_edited=1 OR cards.ai_enriched=1 THEN cards.body  ELSE excluded.body  END''');
      for (final c in cards) {
        st.execute([c.id, c.type.name, c.title, c.body, c.score, _ms(c.createdAt),
          _ms(c.expiresAt), _ms(now), jsonEncode(c.payload)]);
      }
      st.dispose();
    });
  }

  /// Cards to show right now. A card must have been re-confirmed by the evaluator
  /// within the last 20 minutes, so stale conclusions disappear on their own.
  List<PulseCard> active({DateTime? now, int limit = ContextEvaluator.maxCards}) {
    final t = _ms(now ?? DateTime.now());
    final rs = _db.select('''
SELECT * FROM cards
WHERE status='active' AND expires_ms>? AND last_seen_ms>=?
  AND (snoozed_until_ms IS NULL OR snoozed_until_ms<=?) AND score>=?
ORDER BY score DESC LIMIT ?''',
        [t, t - 20 * 60 * 1000, t, ContextEvaluator.minScore, limit]);
    return rs.map((r) => PulseCard.fromMap(_m(r))).toList();
  }

  PulseCard? get(String id) {
    final rs = _db.select('SELECT * FROM cards WHERE id=?', [id]);
    return rs.isEmpty ? null : PulseCard.fromMap(_m(rs.first));
  }

  void setStatus(String id, CardStatus s) =>
      _db.execute('UPDATE cards SET status=? WHERE id=?', [s.name, id]);

  void snooze(String id, DateTime until) =>
      _db.execute('UPDATE cards SET snoozed_until_ms=? WHERE id=?', [_ms(until), id]);

  void updateText(String id, String title, String body) => _db.execute(
      'UPDATE cards SET title=?, body=?, user_edited=1 WHERE id=?', [title, body, id]);

  void markEnriched(String id, int state, {String? title, String? body}) {
    if (title != null && body != null) {
      _db.execute('UPDATE cards SET title=?, body=?, ai_enriched=? WHERE id=? AND user_edited=0',
          [title, body, state, id]);
    } else {
      _db.execute('UPDATE cards SET ai_enriched=? WHERE id=?', [state, id]);
    }
  }

  /// Free-tier quota support.
  int createdSince(DateTime t) => _db
      .select('SELECT COUNT(*) c FROM cards WHERE created_ms>=?', [_ms(t)]).first['c'] as int;

  Set<String> existingIds(List<String> ids) {
    if (ids.isEmpty) return {};
    final ph = List.filled(ids.length, '?').join(',');
    return _db.select('SELECT id FROM cards WHERE id IN ($ph)', ids).map((r) => r['id'] as String).toSet();
  }

  /// Visible, high-priority cards that have never produced a notification.
  List<PulseCard> unnotified(double minScore, {int limit = 2}) {
    final now = DateTime.now();
    return active(now: now, limit: 10)
        .where((c) => c.score >= minScore)
        .where((c) => _db.select('SELECT notified FROM cards WHERE id=?', [c.id]).first['notified'] == 0)
        .take(limit)
        .toList();
  }

  void markNotified(String id) => _db.execute('UPDATE cards SET notified=1 WHERE id=?', [id]);

  List<PulseCard> allForExport() =>
      _db.select('SELECT * FROM cards ORDER BY created_ms DESC').map((r) => PulseCard.fromMap(_m(r))).toList();

  void deleteOld(DateTime now) => _db.execute('DELETE FROM cards WHERE expires_ms<?',
      [_ms(now.subtract(const Duration(days: 2)))]);
}

// ============================================================== User actions
class ActionRepository {
  ActionRepository(this._db);
  final Database _db;

  void log(UserAction a) => _db.execute(
      'INSERT INTO actions(card_id,kind,note,amount,created_ms) VALUES(?,?,?,?,?)',
      [a.cardId, a.kind.name, a.note, a.amount, _ms(a.createdAt)]);

  List<UserAction> recent({int limit = 50}) => _db
      .select('SELECT * FROM actions ORDER BY created_ms DESC LIMIT ?', [limit])
      .map((r) => UserAction.fromMap(_m(r)))
      .toList();

  double spentToday(DateTime now) {
    final start = DateTime(now.year, now.month, now.day);
    final r = _db.select(
        "SELECT COALESCE(SUM(amount),0) s FROM actions WHERE kind='expense' AND created_ms>=?",
        [_ms(start)]);
    return (r.first['s'] as num).toDouble();
  }
}

// ============================================================== Habits
class HabitRepository {
  HabitRepository(this._db);
  final Database _db;

  List<Habit> all() => _db
      .select('SELECT * FROM habits ORDER BY hour, title')
      .map((r) => Habit.fromMap(_m(r)))
      .toList();

  void add(String title, int hour, {int windowMin = 120}) => _db.execute(
      'INSERT INTO habits(title,hour,window_min) VALUES(?,?,?)', [title, hour, windowMin]);

  void remove(int id) => _db.execute('DELETE FROM habits WHERE id=?', [id]);

  void markDone(int id, DateTime at) =>
      _db.execute('UPDATE habits SET last_done_ms=? WHERE id=?', [_ms(at), id]);

  void seedIfEmpty() {
    final n = _db.select('SELECT COUNT(*) c FROM habits').first['c'] as int;
    if (n > 0) return;
    add('Drink a glass of water', 11);
    add('Stretch / stand up', 15, windowMin: 90);
    add("Review tomorrow's plan", 21, windowMin: 90);
  }
}

// ============================================================== Calendar cache
class EventRepository {
  EventRepository(this._db);
  final Database _db;

  void replaceAll(List<ScheduleEvent> events) => inTransaction(_db, () {
        _db.execute('DELETE FROM events');
        final st = _db.prepare(
            'INSERT OR REPLACE INTO events(id,title,start_ms,end_ms,location) VALUES(?,?,?,?,?)');
        for (final e in events) {
          st.execute([e.id, e.title, _ms(e.start), _ms(e.end), e.location]);
        }
        st.dispose();
      });

  List<ScheduleEvent> upcoming() => _db
      .select('SELECT * FROM events ORDER BY start_ms')
      .map((r) => ScheduleEvent.fromMap(_m(r)))
      .toList();
}

// ============================================================== Signal history
class SignalRepository {
  SignalRepository(this._db);
  final Database _db;

  void insert(ContextSignal s, double score) => _db.execute(
      'INSERT INTO signals(ts,activity,network,battery,charging,next_event_min,context_score) VALUES(?,?,?,?,?,?,?)',
      [_ms(s.timestamp), s.activity.name, s.network.name, s.batteryLevel,
        s.isCharging ? 1 : 0, s.minutesToNextEvent, score]);

  /// Keep only a week of history: less data at rest, smaller DB.
  void prune(DateTime now) => _db.execute('DELETE FROM signals WHERE ts<?',
      [_ms(now.subtract(const Duration(days: 7)))]);
}

// ============================================================== Offline queue
/// Cards waiting for optional AI enrichment. Survives restarts; drained when online.
class EnrichQueueRepository {
  EnrichQueueRepository(this._db);
  final Database _db;

  /// Calendar cards are never queued: event titles must not leave the device.
  void enqueueEligible(List<String> cardIds, DateTime now) {
    if (cardIds.isEmpty) return;
    final ph = List.filled(cardIds.length, '?').join(',');
    _db.execute('''
INSERT OR IGNORE INTO enrich_queue(card_id, queued_ms)
SELECT id, ? FROM cards
WHERE id IN ($ph) AND ai_enriched=0 AND user_edited=0 AND status='active' AND type!='calendar' ''',
        [_ms(now), ...cardIds]);
  }

  List<String> pending({int limit = 3}) => _db
      .select('SELECT card_id FROM enrich_queue ORDER BY queued_ms LIMIT ?', [limit])
      .map((r) => r['card_id'] as String)
      .toList();

  void remove(String id) => _db.execute('DELETE FROM enrich_queue WHERE card_id=?', [id]);

  int count() => _db.select('SELECT COUNT(*) c FROM enrich_queue').first['c'] as int;
}


// ============================================================== Pro: custom rules
class RuleRepository {
  RuleRepository(this._db);
  final Database _db;

  List<UserRule> all() =>
      _db.select('SELECT * FROM rules ORDER BY id DESC').map((r) => UserRule.fromMap(_m(r))).toList();

  List<UserRule> enabled() => all().where((r) => r.enabled).toList();

  int save(UserRule r) {
    if (r.id == null) {
      _db.execute('INSERT INTO rules(name,title,body,conditions,score,enabled) VALUES(?,?,?,?,?,?)',
          [r.name, r.title, r.body, r.conditionsJson(), r.score, r.enabled ? 1 : 0]);
      return _db.lastInsertRowId;
    }
    _db.execute('UPDATE rules SET name=?,title=?,body=?,conditions=?,score=?,enabled=? WHERE id=?',
        [r.name, r.title, r.body, r.conditionsJson(), r.score, r.enabled ? 1 : 0, r.id]);
    return r.id!;
  }

  void setEnabled(int id, bool on) =>
      _db.execute('UPDATE rules SET enabled=? WHERE id=?', [on ? 1 : 0, id]);

  void delete(int id) => _db.execute('DELETE FROM rules WHERE id=?', [id]);
}
