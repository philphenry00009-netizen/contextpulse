import 'package:flutter/widgets.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import '../domain/entities.dart';
import 'context_engine.dart';

/// Smart notifications with inline "Complete" and "Snooze 1h" buttons.
class NotificationService {
  static final _plugin = FlutterLocalNotificationsPlugin();
  static const _chUrgent = AndroidNotificationChannel(
      'pulse_urgent', 'Urgent pulses',
      description: 'Time-critical cards: imminent events, low battery',
      importance: Importance.high);
  static const _chRules = AndroidNotificationChannel(
      'pulse_rules', 'Your rules',
      description: 'Cards triggered by your custom rules', importance: Importance.defaultImportance);
  static const notifyThreshold = 80.0;

  static Future<void> init() async {
    await _plugin.initialize(
      const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')),
      onDidReceiveNotificationResponse: handleResponse,
      onDidReceiveBackgroundNotificationResponse: notificationBackgroundHandler,
    );
    final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await android?.createNotificationChannel(_chUrgent);
    await android?.createNotificationChannel(_chRules);
  }

  /// Android 13+ only (no-op prompt on Android 12 and below).
  static Future<void> requestPermission() async {
    await _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();
  }

  static int _id(String cardId) => cardId.hashCode & 0x7fffffff;

  static Future<void> show(PulseCard c) async {
    final ch = c.type == CardType.custom ? _chRules : _chUrgent;
    await _plugin.show(
      _id(c.id),
      c.title,
      c.body,
      NotificationDetails(
        android: AndroidNotificationDetails(
          ch.id,
          ch.name,
          channelDescription: ch.description,
          importance: ch.importance,
          priority: Priority.high,
          category: AndroidNotificationCategory.reminder,
          styleInformation: BigTextStyleInformation(c.body),
          actions: const [
            AndroidNotificationAction('complete', 'Complete', cancelNotification: true),
            AndroidNotificationAction('snooze1h', 'Snooze 1h', cancelNotification: true),
          ],
        ),
      ),
      payload: c.id,
    );
  }

  static Future<void> cancel(String cardId) => _plugin.cancel(_id(cardId));

  /// Foreground callback (app process alive).
  static Future<void> handleResponse(NotificationResponse r) async {
    final id = r.payload;
    if (id == null || r.actionId == null) return; // plain tap just opens the app
    final engine = await ContextEngine.create();
    final now = DateTime.now();
    if (r.actionId == 'complete') {
      engine.pulses.setStatus(id, CardStatus.completed);
      engine.actions.log(UserAction(cardId: id, kind: ActionKind.completed, createdAt: now));
    } else if (r.actionId == 'snooze1h') {
      engine.pulses.snooze(id, now.add(const Duration(hours: 1)));
      engine.actions.log(UserAction(cardId: id, kind: ActionKind.snoozed, note: '60m', createdAt: now));
    }
    await engine.syncWidget();
  }
}

/// Separate isolate entry point used when the app process is not in the foreground.
@pragma('vm:entry-point')
Future<void> notificationBackgroundHandler(NotificationResponse r) async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.handleResponse(r);
}
