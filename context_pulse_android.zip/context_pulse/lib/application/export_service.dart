import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../domain/entities.dart';
import 'context_engine.dart';

/// Pro: local JSON / CSV export. Files are written to app-private storage and handed to the
/// system share sheet; nothing is uploaded by the app.
class ExportService {
  ExportService(this.engine);
  final ContextEngine engine;

  Future<File> exportJson() async {
    final cards = engine.pulses.allForExport();
    final actions = engine.actions.recent(limit: 100000);
    final data = {
      'exportedAt': DateTime.now().toIso8601String(),
      'cards': [
        for (final c in cards)
          {
            'id': c.id, 'type': c.type.name, 'title': c.title, 'body': c.body, 'score': c.score,
            'status': c.status.name, 'createdAt': c.createdAt.toIso8601String(),
          }
      ],
      'actions': [
        for (final a in actions)
          {
            'kind': a.kind.name, 'cardId': a.cardId, 'note': a.note, 'amount': a.amount,
            'at': a.createdAt.toIso8601String(),
          }
      ],
      'rules': [for (final r in engine.rules.all()) {'name': r.name, 'title': r.title, 'conditions': jsonDecode(r.conditionsJson())}],
    };
    return _write('contextpulse_export.json', const JsonEncoder.withIndent('  ').convert(data));
  }

  Future<File> exportCsv() async {
    final b = StringBuffer('at,kind,card_id,amount,note\n');
    for (final a in engine.actions.recent(limit: 100000)) {
      b.writeln([a.createdAt.toIso8601String(), a.kind.name, a.cardId ?? '', a.amount ?? '', a.note ?? '']
          .map(_csv)
          .join(','));
    }
    return _write('contextpulse_actions.csv', b.toString());
  }

  Future<void> shareFile(File f) => Share.shareXFiles([XFile(f.path)]);

  Future<File> _write(String name, String content) async {
    final dir = await getTemporaryDirectory();
    return File('${dir.path}/$name').writeAsString(content, flush: true);
  }

  /// RFC 4180 quoting + guard against spreadsheet formula injection.
  static String _csv(Object v) {
    var s = v.toString();
    if (s.isNotEmpty && '=+-@'.contains(s[0]) && double.tryParse(s) == null) s = "'$s";
    return (s.contains(',') || s.contains('"') || s.contains('\n')) ? '"${s.replaceAll('"', '""')}"' : s;
  }
}
