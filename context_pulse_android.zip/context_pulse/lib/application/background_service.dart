import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:workmanager/workmanager.dart';
import '../security/integrity_guard.dart';
import 'context_engine.dart';
import 'notification_service.dart';

const kTickTask = 'dev.contextpulse.tick';

/// Executed by WorkManager in a headless isolate.
@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    WidgetsFlutterBinding.ensureInitialized();
    try {
      // Tamper verdict set by the UI isolate: stop doing any work.
      if (await IntegrityGuard().isBlocked()) return true;
      await NotificationService.init();
      final engine = await ContextEngine.create();
      await engine.tick();
    } catch (e, st) {
      debugPrint('ContextPulse background tick failed: $e\n$st');
    }
    return true; // never request retries: each retry is an extra wake-up
  });
}

/// Battery strategy (target < 1%/day, measure it on your device):
///  * ONE periodic WorkManager job at the 15-minute platform minimum, batched by the OS.
///  * Activity comes from the Play Services Transition API (event-driven receiver, no polling).
///  * No always-on foreground service: it shows a permanent notification, defeats Doze, and
///    Android 12+ restricts starting one from the background. WorkManager is the right tool here.
///  * Location only when a Pro rule needs it, and only the cached last-known fix.
class BackgroundService {
  static Future<void> register() async {
    await Workmanager().initialize(callbackDispatcher, isInDebugMode: false);
    await Workmanager().registerPeriodicTask(
      'contextpulse.periodic',
      kTickTask,
      frequency: const Duration(minutes: 15),
      existingWorkPolicy: ExistingWorkPolicy.keep,
    );
  }
}
