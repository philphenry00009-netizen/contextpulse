import 'package:connectivity_plus/connectivity_plus.dart';
import '../billing/license_validator.dart';
import '../core/app_config.dart';
import '../core/secure_store.dart';
import '../data/ai_enricher.dart';
import '../data/app_database.dart';
import '../data/repositories.dart';
import '../data/signal_collector.dart';
import '../domain/context_evaluator.dart';
import '../domain/entities.dart';
import '../domain/rules.dart';
import 'notification_service.dart';
import 'widget_sync.dart';

class TickResult {
  const TickResult(this.signal, this.score, this.isPro);
  final ContextSignal signal;
  final double score;
  final bool isPro;
}

/// One full pass: collect -> evaluate -> apply tier limits -> persist -> notify -> widget.
/// Identical in the foreground UI and the WorkManager isolate.
class ContextEngine {
  ContextEngine(AppDatabase db, {SignalCollector? collector, ContextEvaluator? evaluator})
      : pulses = PulseRepository(db.raw),
        actions = ActionRepository(db.raw),
        habits = HabitRepository(db.raw),
        events = EventRepository(db.raw),
        signals = SignalRepository(db.raw),
        queue = EnrichQueueRepository(db.raw),
        rules = RuleRepository(db.raw),
        collector = collector ?? SignalCollector(),
        evaluator = evaluator ?? const ContextEvaluator() {
    enricher = AiEnricher(store, pulses, queue);
  }

  static Future<ContextEngine> create() async => ContextEngine(await AppDatabase.connect());

  final PulseRepository pulses;
  final ActionRepository actions;
  final HabitRepository habits;
  final EventRepository events;
  final SignalRepository signals;
  final EnrichQueueRepository queue;
  final RuleRepository rules;
  final SignalCollector collector;
  final ContextEvaluator evaluator;
  final SecureStore store = SecureStore();
  final LicenseValidator license = LicenseValidator();
  late final AiEnricher enricher;
  double _lastScore = 0;

  Future<TickResult> tick() async {
    final pro = await license.isPro(); // cached, signature verified earlier in the UI isolate
    final activeRules = pro ? rules.enabled() : const <UserRule>[];
    final signal = await collector.collect(wantLocation: activeRules.any((r) => r.needsLocation));
    final score = evaluator.contextScore(signal);
    _lastScore = score;

    events.replaceAll(signal.upcomingEvents);
    var cards = evaluator.evaluate(signal, habits.all(), rules: activeRules);
    if (!pro) cards = _applyFreeQuota(cards, signal.timestamp);

    pulses.upsertAll(cards, signal.timestamp);
    signals.insert(signal, score);
    signals.prune(signal.timestamp);
    pulses.deleteOld(signal.timestamp);

    // Notify (max 2 per tick, once per card). Focus mode has already filtered low scores.
    for (final c in pulses.unnotified(NotificationService.notifyThreshold)) {
      await NotificationService.show(c);
      pulses.markNotified(c.id);
    }

    if (await store.aiOptIn()) {
      queue.enqueueEligible(cards.map((c) => c.id).toList(), signal.timestamp);
      if (signal.network != NetworkState.offline) await enricher.processQueue();
    }
    await syncWidget();
    return TickResult(signal, score, pro);
  }

  Future<void> syncWidget() => WidgetSync.update(pulses.active(limit: 3), _lastScore);

  /// Free tier: at most [AppConfig.freeDailyCardQuota] distinct cards created per day.
  /// Cards that already exist today keep updating; only brand-new ones consume quota.
  List<PulseCard> _applyFreeQuota(List<PulseCard> cards, DateTime now) {
    final startOfDay = DateTime(now.year, now.month, now.day);
    var remaining = AppConfig.freeDailyCardQuota - pulses.createdSince(startOfDay);
    final existing = pulses.existingIds(cards.map((c) => c.id).toList());
    final out = <PulseCard>[];
    for (final c in cards) {
      if (existing.contains(c.id)) {
        out.add(c);
      } else if (remaining > 0) {
        out.add(c);
        remaining--;
      }
    }
    return out;
  }

  static bool isOffline(List<ConnectivityResult> r) =>
      r.isEmpty || r.every((e) => e == ConnectivityResult.none);
}
