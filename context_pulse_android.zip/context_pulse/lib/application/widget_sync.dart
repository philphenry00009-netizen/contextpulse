import 'package:home_widget/home_widget.dart';
import '../domain/entities.dart';

/// Pushes the top cards into the native Home Screen widget (PulseWidgetProvider.kt).
class WidgetSync {
  static const provider = 'dev.contextpulse.context_pulse.PulseWidgetProvider';

  static Future<void> update(List<PulseCard> cards, double contextScore) async {
    try {
      await HomeWidget.saveWidgetData<int>('w_score', contextScore.round());
      await HomeWidget.saveWidgetData<int>('w_count', cards.length.clamp(0, 3));
      for (var i = 0; i < 3; i++) {
        final c = i < cards.length ? cards[i] : null;
        await HomeWidget.saveWidgetData<String>('w_title_$i', c?.title ?? '');
        await HomeWidget.saveWidgetData<String>('w_body_$i', c?.body ?? '');
      }
      await HomeWidget.updateWidget(qualifiedAndroidName: provider);
    } catch (_) {
      // Widget not placed / plugin unavailable: ignore.
    }
  }
}
