import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:workmanager/workmanager.dart';
import '../core/app_config.dart';
import '../core/native_bridge.dart';
import '../core/secure_store.dart';

enum IntegrityVerdict { ok, tampered, unknown }

class IntegrityReport {
  const IntegrityReport(this.verdict, this.reason, {this.rooted = false});
  final IntegrityVerdict verdict;
  final String reason;
  final bool rooted;
}

/// Layered anti-tamper checks:
///  1. Signing certificate hash must equal your Play App Signing cert (catches repacking).
///  2. Installer must be Google Play (catches sideloaded copies).
///  3. Play Integrity token verified by YOUR server (the only trustworthy verdict, since the
///     token can only be decrypted server-side with Google's API). See server/verify_integrity.py.
///  4. Root heuristics (hook only; policy in AppConfig.blockOnRoot).
///
/// IMPORTANT: no client-side check is "non-bypassable". A skilled attacker can patch the Dart
/// snapshot or hook the channel. These checks stop casual repackaging and make piracy costly;
/// they are not a guarantee. Fail-open is used when offline so legitimate users are never locked out.
class IntegrityGuard {
  IntegrityGuard([SecureStore? store]) : _store = store ?? SecureStore();
  final SecureStore _store;
  static const _kFailed = 'integrity_failed';
  static const _kLastGood = 'integrity_last_good';

  /// Background isolate calls this first and exits if the flag is set.
  Future<bool> isBlocked() async => (await _store.read(_kFailed)) == '1';

  Future<IntegrityReport> check() async {
    final rooted = await NativeBridge.isRooted();
    if (!AppConfig.enforceSecurity) {
      return IntegrityReport(IntegrityVerdict.ok, 'enforcement disabled (debug / unconfigured)',
          rooted: rooted);
    }

    // 1 + 2: local, offline-safe, deterministic.
    final cert = (await NativeBridge.signingCertSha256())?.toLowerCase();
    if (cert == null || cert != AppConfig.expectedSigningCertSha256.toLowerCase()) {
      return _fail('signing certificate mismatch', rooted);
    }
    final installer = await NativeBridge.installerPackage();
    if (installer != 'com.android.vending') return _fail('not installed from Google Play', rooted);

    // 3: server-verified Play Integrity (needs network + your backend).
    if (AppConfig.integrityVerifierUrl.isNotEmpty) {
      final server = await _serverVerdict();
      if (server == false) return _fail('Play Integrity rejected', rooted);
      if (server == true) {
        await _store.write(_kLastGood, DateTime.now().millisecondsSinceEpoch.toString());
      }
      // null = could not reach server: keep working (offline-first), rely on 1 + 2.
    }

    if (rooted && AppConfig.blockOnRoot) return _fail('rooted device', rooted);
    await _store.write(_kFailed, '0');
    return IntegrityReport(IntegrityVerdict.ok, 'ok', rooted: rooted);
  }

  Future<bool?> _serverVerdict() async {
    try {
      final r = Random.secure();
      final nonce = base64Url.encode(List.generate(32, (_) => r.nextInt(256)));
      final token = await NativeBridge.integrityToken(nonce, AppConfig.cloudProjectNumber);
      if (token == null) return null;
      final res = await http
          .post(Uri.parse(AppConfig.integrityVerifierUrl),
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode({'token': token, 'nonce': nonce}))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode != 200) return null;
      final j = jsonDecode(res.body) as Map<String, dynamic>;
      // Server returns {"appIntegrity": bool, "deviceIntegrity": bool, "nonceOk": bool}
      return j['appIntegrity'] == true && j['deviceIntegrity'] == true && j['nonceOk'] == true;
    } on SocketException {
      return null;
    } catch (e) {
      debugPrint('integrity server check failed: $e');
      return null;
    }
  }

  Future<IntegrityReport> _fail(String why, bool rooted) async {
    await _store.write(_kFailed, '1'); // background worker reads this and stops
    try {
      await Workmanager().cancelAll(); // halt background execution
    } catch (_) {}
    return IntegrityReport(IntegrityVerdict.tampered, why, rooted: rooted);
  }
}
