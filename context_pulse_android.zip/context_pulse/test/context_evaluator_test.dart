import 'package:context_pulse/domain/context_evaluator.dart';
import 'package:context_pulse/domain/entities.dart';
import 'package:context_pulse/domain/rules.dart';
import 'package:flutter_test/flutter_test.dart';

ContextSignal sig({
  DateTime? at,
  ActivityState a = ActivityState.stationary,
  NetworkState n = NetworkState.wifi,
  int battery = 80,
  bool charging = false,
  List<ScheduleEvent> events = const [],
}) =>
    ContextSignal(
      timestamp: at ?? DateTime(2026, 10, 16, 14, 0),
      activity: a,
      network: n,
      batteryLevel: battery,
      isCharging: charging,
      upcomingEvents: events,
    );

void main() {
  const ev = ContextEvaluator();

  test('imminent event outranks everything and carries a reason', () {
    final t = DateTime(2026, 10, 16, 14, 0);
    final s = sig(events: [
      ScheduleEvent(id: 'a', title: 'Standup', start: t.add(const Duration(minutes: 10)), end: t.add(const Duration(minutes: 40)), location: 'Room 2'),
    ]);
    final cards = ev.evaluate(s, const []);
    expect(cards.first.type, CardType.calendar);
    expect(cards.first.score, greaterThan(80));
    expect(cards.first.why, isNotEmpty);
  });

  test('low battery produces a high-priority card; charging suppresses it', () {
    expect(ev.evaluate(sig(battery: 8), const []).first.type, CardType.battery);
    expect(ev.evaluate(sig(battery: 8, charging: true), const []), isEmpty);
  });

  test('habit in window shows once; done today hides it', () {
    final h = Habit(id: 1, title: 'Water', hour: 14);
    expect(ev.evaluate(sig(), [h]).any((c) => c.type == CardType.habit), isTrue);
    final done = Habit(id: 1, title: 'Water', hour: 14, lastDone: DateTime(2026, 10, 16, 9));
    expect(ev.evaluate(sig(), [done]).any((c) => c.type == CardType.habit), isFalse);
  });

  test('driving mutes non-urgent cards and lowers context score', () {
    final h = Habit(id: 1, title: 'Water', hour: 14);
    expect(ev.evaluate(sig(a: ActivityState.driving), [h]).where((c) => c.type == CardType.habit), isEmpty);
    expect(ev.contextScore(sig(a: ActivityState.driving)), lessThan(ev.contextScore(sig())));
  });

  test('never returns more than 5 cards, sorted by score', () {
    final habits = [for (var i = 0; i < 9; i++) Habit(id: i, title: 'H$i', hour: 14)];
    final cards = ev.evaluate(sig(battery: 5), habits);
    expect(cards.length, lessThanOrEqualTo(5));
    for (var i = 1; i < cards.length; i++) {
      expect(cards[i - 1].score, greaterThanOrEqualTo(cards[i].score));
    }
  });

  test('custom rule fires only when ALL conditions match', () {
    final rule = UserRule(id: 1, name: 'Evening low battery', title: 'Charge up', body: '', conditions: const [
      TimeRangeCondition(13 * 60, 15 * 60),
      BatteryCondition(below: true, percent: 50),
    ]);
    // 14:00, battery 30% -> matches
    expect(ev.evaluate(sig(battery: 30), const [], rules: [rule]).any((c) => c.type == CardType.custom), isTrue);
    // battery 80% -> battery condition fails
    expect(ev.evaluate(sig(battery: 80), const [], rules: [rule]).any((c) => c.type == CardType.custom), isFalse);
    // outside time window
    final late = sig(battery: 30, at: DateTime(2026, 10, 16, 20, 0));
    expect(ev.evaluate(late, const [], rules: [rule]).any((c) => c.type == CardType.custom), isFalse);
  });

  test('overnight time range wraps midnight', () {
    const c = TimeRangeCondition(22 * 60, 6 * 60);
    expect(c.matches(sig(at: DateTime(2026, 10, 16, 23, 30))), isTrue);
    expect(c.matches(sig(at: DateTime(2026, 10, 16, 5, 0))), isTrue);
    expect(c.matches(sig(at: DateTime(2026, 10, 16, 12, 0))), isFalse);
  });

  test('place condition needs a location and respects radius', () {
    const home = PlaceCondition(label: 'Home', lat: 6.5244, lng: 3.3792, radiusM: 200, inside: true);
    expect(home.matches(sig()), isFalse); // no location known
    final near = ContextSignal(
        timestamp: DateTime(2026, 10, 16, 14), activity: ActivityState.stationary, network: NetworkState.wifi,
        batteryLevel: 80, isCharging: false, latitude: 6.5245, longitude: 3.3793);
    expect(home.matches(near), isTrue);
  });

  test('rule conditions survive a JSON round trip', () {
    const r = UserRule(name: 'x', title: 't', body: '', conditions: [
      TimeRangeCondition(60, 120), BatteryCondition(below: true, percent: 20),
      WeekdayCondition({1, 2}), ActivityCondition(ActivityState.walking),
    ]);
    final back = UserRule.parseConditions(r.conditionsJson());
    expect(back.map((c) => c.describe()), r.conditions.map((c) => c.describe()));
  });

  test('focus mode hides low-priority cards', () {
    final h = Habit(id: 1, title: 'Water', hour: 14);
    final focus = ContextSignal(
        timestamp: DateTime(2026, 10, 16, 14), activity: ActivityState.stationary, network: NetworkState.wifi,
        batteryLevel: 80, isCharging: false, focusMode: true);
    expect(ev.evaluate(focus, [h]), isEmpty);
  });
}
