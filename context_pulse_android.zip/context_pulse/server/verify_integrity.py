"""
Reference Play Integrity verifier (run on YOUR backend; never ship credentials in the app).

  pip install flask google-auth requests
  export GOOGLE_APPLICATION_CREDENTIALS=service-account.json   # SA with Play Integrity API enabled
  export PACKAGE_NAME=dev.contextpulse.context_pulse
  flask --app verify_integrity run

The app POSTs {"token","nonce"}; we ask Google to decode it and return simple booleans.
Keep a server-side record of issued nonces in production to prevent replay.
"""
import os
import google.auth
import google.auth.transport.requests
import requests
from flask import Flask, jsonify, request

app = Flask(__name__)
PKG = os.environ["PACKAGE_NAME"]
creds, _ = google.auth.default(scopes=["https://www.googleapis.com/auth/playintegrity"])


@app.post("/")
def verify():
    body = request.get_json(force=True)
    creds.refresh(google.auth.transport.requests.Request())
    r = requests.post(
        f"https://playintegrity.googleapis.com/v1/{PKG}:decodeIntegrityToken",
        headers={"Authorization": f"Bearer {creds.token}"},
        json={"integrity_token": body["token"]},
        timeout=10,
    )
    if r.status_code != 200:
        return jsonify(appIntegrity=False, deviceIntegrity=False, nonceOk=False), 200
    p = r.json()["tokenPayloadExternal"]
    app_ok = (p["appIntegrity"].get("appRecognitionVerdict") == "PLAY_RECOGNIZED"
              and p["appIntegrity"].get("packageName") == PKG)
    dev_ok = "MEETS_DEVICE_INTEGRITY" in p["deviceIntegrity"].get("deviceRecognitionVerdict", [])
    nonce_ok = p["requestDetails"].get("nonce") == body["nonce"] \
        or p["requestDetails"].get("nonce", "").rstrip("=") == body["nonce"].rstrip("=")
    return jsonify(appIntegrity=app_ok, deviceIntegrity=dev_ok, nonceOk=nonce_ok)
