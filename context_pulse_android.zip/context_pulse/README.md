# ContextPulse (Android, Flutter, Material 3)

Offline-first ambient context engine. Pulse Cards: swipe right = done, swipe left = snooze, tap = why / edit.

```
lib/
  core/          app_config (fill in!), secure_store (Keystore), native_bridge, shared_flags, theme (M3)
  domain/        entities, context_evaluator (scoring), rules (Pro rule model + matching)
  data/          app_database (SQLCipher, schema v2), repositories, signal_collector, ai_enricher (opt-in)
  billing/       license_validator (offline RSA receipt check), billing_service (Play Billing), pro_cubit
  security/      integrity_guard (cert + installer + Play Integrity + root hook)
  application/   context_engine (one tick), background_service (WorkManager),
                 notification_service (inline actions), widget_sync, export_service
  presentation/  bloc/ (pulse, theme, rule_builder), pages/ (dashboard, rules, rule builder,
                 settings, shell, security gate), widgets/
android_overlay/ Kotlin + XML: MainActivity, Activity Recognition receiver, 2 QS tiles, home widget
server/          verify_integrity.py  (reference Play Integrity verifier)
test/            evaluator + rule tests
```

## 1. Set up
```bash
flutter --version                  # needs Flutter 3.27+
flutter create --org dev.contextpulse --project-name context_pulse .   # generates android/
flutter pub get
cp -r android_overlay/app/src/main/* android/app/src/main/   # Kotlin, res, replaces MainActivity.kt
```
Then apply by hand: `android_overlay/AndroidManifest_additions.xml` and `android_overlay/build_gradle_additions.md`.
The package must stay `dev.contextpulse.context_pulse` (the Kotlin files use it).

## 2. Fill in `lib/core/app_config.dart`
| Setting | Where to get it |
|---|---|
| `playLicenseKeyBase64` | Play Console > Monetize > Monetization setup > Licensing |
| `proMonthlyId` / `proYearlyId` | Subscriptions you create ($1.99/mo, $14.99/yr) |
| `cloudProjectNumber` | Play Console > App integrity > link a Cloud project |
| `expectedSigningCertSha256` | Play Console > App integrity > App signing key certificate (SHA-256, hex, no colons) |
| `integrityVerifierUrl` | Deploy `server/verify_integrity.py` (optional but strongly advised) |

## 3. Run / test
```bash
flutter run                      # debug: security + billing enforcement are off or inert
flutter test
```
* A USB phone is the best test target (real sensors, widgets, tiles, notifications).
* Add widget: long-press home screen > Widgets > ContextPulse. Tiles: pull down Quick Settings > pencil > drag "Focus" / "Scan now".
* Tiles and Pro features need Pro. For testing, add your Google account as a **license tester** in Play Console and install via an **internal testing** track; debug sideloads cannot buy.
* Notification actions: set a rule priority to "High + notify", or drop battery below 10% on an emulator.
* Release: `flutter build appbundle --release --obfuscate --split-debug-info=build/symbols`.

## 4. How the pieces work
* **Encryption**: SQLCipher (AES-256) via `sqlite3` + `sqlcipher_flutter_libs`, key generated once and held in the Keystore-backed secure store. The app refuses to open the DB if SQLCipher is not linked. (I used the `sqlite3` package directly instead of Drift: same encryption, no code generation. Say so if you want Drift.)
* **Activity**: Play Services Transition API wakes `ActivityTransitionReceiver` on change only; Dart reads the last state next tick. Falls back to accelerometer.
* **Background**: one 15-minute WorkManager job. **No foreground service**: it needs a permanent notification, fights Doze, and Android 12+ blocks starting one from the background. It would also contradict the battery goal.
* **Free vs Pro**: free = 5 new cards per day, no rules/tiles/themes/export. Pro = everything. Gating happens in `ContextEngine`, `ProCubit`, and the tiles.
* **Receipts**: `LicenseValidator` verifies Play's RSA signature natively, checks package/product/state, caches in the Keystore store, re-verifies on each launch, and keeps Pro for 7 days after Play last confirmed it (offline grace).
* **Anti-tamper**: signing-cert hash + installer == Google Play + (optional) server-decoded Play Integrity token. On failure: background work is cancelled, a flag stops the worker, and a non-dismissible dialog with the exact message you specified replaces the UI.

## 5. Honest limitations
* **"Non-bypassable" does not exist on the client.** Anyone who controls the device can patch Dart/Kotlin or hook the channel. Only the server-verified Play Integrity verdict is trustworthy, so deploy the verifier. Without it you get cert + installer checks only, which deter casual repackaging.
* The check **fails open when offline** and while it runs, so honest users are never locked out. It also never triggers in debug builds.
* Pro entitlement is verified locally; a lapsed subscription can stay unlocked up to 7 days. For strict enforcement add server-side purchase verification (Play Developer API).
* The QS tile Pro gate reads a flag Dart writes to shared preferences, so it is a UX gate, not security.
* Place rules use the cached last-known location. Evaluating them in the background needs "Allow all the time" location, which Google Play reviews strictly; declare it only if you ship place rules.
* Battery whitelist opens the system list instead of using `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`, because Play restricts that permission.
* Predictive back animates only on Android 13+ (and needs `android:enableOnBackInvokedCallback="true"` on `<application>` plus the developer option on 13); older versions use the standard transition.
* **Not compiled here** (no Flutter/Android toolchain in my sandbox). Expect small API-drift fixes after `pub get` (`workmanager`, `device_calendar`, `home_widget`, `in_app_purchase` versions, Gemini model name).
